# MemeBot

สแกนเหรียญมีม pump.fun แบบ paper trading · ตัวแอปคือไฟล์เดียว `www/index.html` (vanilla JS) ห่อเป็น APK ด้วย Capacitor ผ่าน GitHub Actions

## ได้ APK (ไม่ต้องลง Android Studio)
1. สร้าง repo ใหม่บน GitHub แล้ว push โฟลเดอร์นี้ขึ้น branch `main`
2. แท็บ **Actions → Build APK** รอจบ (ประมาณ 5-8 นาที) หรือกด **Run workflow**
3. เปิดรันที่เสร็จ → เปิดแท็บ **Releases** ของ repo (ขวามือ) → กดโหลด `memebot.apk` ติดตั้งในมือถือได้ตรง ๆ (หรือใช้ artifact **memebot-debug-apk** ก็ได้) (เปิด "ติดตั้งจากแหล่งที่ไม่รู้จัก")

## เว็บ/PWA (ใช้ LIVE ได้ผ่านเบราว์เซอร์)
Settings → Pages → Source = **GitHub Actions** แล้ว push อีกครั้ง จะได้ลิงก์ `https://<user>.github.io/<repo>/` (ติดตั้งเป็น PWA ได้)

## รันในเครื่อง
`npx serve www` หรือเปิด `www/index.html` ตรง ๆ · build เอง: `npm install && npx cap add android && npx cap sync android && npm run apk`

## หมายเหตุ
- APK ที่ได้เป็น **debug** (เซ็นด้วย debug key) ใช้ส่วนตัวได้ ถ้าจะปล่อยจริงต้องทำ release keystore เพิ่ม
- `CapacitorHttp` เปิดไว้ให้ fetch (RPC) ผ่านเนทีฟ ไม่ติด CORS · WebSocket PumpPortal ต่อได้ตรงใน WebView
- ซื้อ/ขายเป็น paper เท่านั้น ไม่มีการเซ็นธุรกรรมจริง

- จำลองธุรกรรม (แท็บสแกน): สร้างธุรกรรมจาก PumpPortal `trade-local` แล้ว `simulateTransaction` ผ่าน RPC ของคุณ **ไม่เซ็น ไม่ส่ง** ใช้แค่ public address
- Phantom ใน APK ไม่ถูกฉีดให้ WebView: ตั้ง GitHub Pages (`pages.yml`) แล้วใส่ลิงก์ในตั้งค่า กด "เปิดใน Phantom" เพื่อเปิดแอปในเบราว์เซอร์ของ Phantom

- v18: LIVE ต่อใหม่อัตโนมัติ (ไม่เด้งไป SIM), ไอคอนโหลดล่วงหน้า, เชื่อม Phantom ใน APK ผ่าน deeplink `memebot://phantom` (ต้อง `@capacitor/app` + intent-filter ที่ workflow ใส่ให้) · อ่านยอดกระเป๋าได้โดยไม่ต้องตั้ง RPC (ใช้ public RPC) แต่ audit ต้องใช้ Helius
- v19: ดึง Top 20 holder จริงจากเชนผ่าน RPC (ใส่ Helius ในตั้งค่า) ก่อนซื้อทุกครั้ง
- v20: เปิดแอปเป็น LIVE, เชื่อม Phantom ปุ่มเดียว (จำกระเป๋า), RPC สาธารณะสำรองอัตโนมัติ, แสดง "ตรวจไม่ได้" แทนการอ้างว่าปลอดภัย
