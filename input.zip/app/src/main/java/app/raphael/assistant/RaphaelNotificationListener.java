package app.raphael.assistant;

import android.service.notification.NotificationListenerService;

/**
 * Registers Raphael as a notification listener so the user can grant "Notification access" in system
 * settings. It currently does not read or store any notification; it only reports whether it is connected.
 */
public class RaphaelNotificationListener extends NotificationListenerService {
    static volatile boolean connected = false;

    @Override public void onListenerConnected() { connected = true; }

    @Override public void onListenerDisconnected() { connected = false; }
}
