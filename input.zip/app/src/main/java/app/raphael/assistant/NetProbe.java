package app.raphael.assistant;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

/** Tells FileDownloader whether the phone may download right now (online? on Wi-Fi when "Wi-Fi only" is on?). */
final class NetProbe implements FileDownloader.Net {
    private final Context ctx;

    NetProbe(Context c) { ctx = c.getApplicationContext(); }

    private NetworkCapabilities caps(ConnectivityManager cm) {
        Network n = cm.getActiveNetwork();
        return n == null ? null : cm.getNetworkCapabilities(n);
    }

    @Override
    public int check(boolean wifiOnly) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = caps(cm);
            if (nc == null || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return OFFLINE;
            if (wifiOnly) {
                boolean wifi = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
                // Only mobile data (or an unknown metered link) counts as "not Wi-Fi"; a Wi-Fi that Android
                // flags as metered (phone hotspot, router) is still Wi-Fi for this switch.
                if (!wifi && (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || cm.isActiveNetworkMetered()))
                    return NEED_WIFI;
            }
            return OK;
        } catch (Throwable t) {
            return OK; // never block a download because the probe itself failed
        }
    }

    /** "wifi" | "cell" | "other" | "none" – shown in the UI. */
    String kind() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = caps(cm);
            if (nc == null || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "none";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "cell";
            return "other";
        } catch (Throwable t) {
            return "other";
        }
    }
}
