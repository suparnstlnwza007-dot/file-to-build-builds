package app.raphael.assistant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLException;

/**
 * In-app resumable HTTPS downloader (v14.1). Replaces Android's DownloadManager, which on many phones
 * (Xiaomi/HyperOS in particular, or whenever "Wi-Fi only" met mobile data) sat forever at
 * "waiting for network · 0 bytes" without ever telling the user why.
 *
 * - writes to "<name>.part" and renames to "<name>" when complete; "<name>.part.src" remembers the URL
 * - resumes with HTTP Range after a drop / app restart; follows redirects by hand (Hugging Face -> CDN)
 * - waits (does not fail) while offline or while "Wi-Fi only" is on and the phone is on mobile data
 * - every failure carries a readable message for the UI
 *
 * No Android classes are used here on purpose, so it can be tested on a desktop JVM.
 * Status numbers match android.app.DownloadManager, so the web UI contract did not change.
 */
final class FileDownloader {
    static final int PENDING = 1, RUNNING = 2, PAUSED = 4, SUCCESSFUL = 8, FAILED = 16;
    /** PAUSED reasons (same numbers as DownloadManager.PAUSED_*). */
    static final int WAIT_RETRY = 1, WAIT_NETWORK = 2, WAIT_WIFI = 3;
    /** FAILED reasons (same numbers as DownloadManager.ERROR_*). */
    static final int ERR_FILE = 1001, ERR_HTTP = 1002, ERR_IO = 1004, ERR_SPACE = 1006;

    /** Network gate supplied by the app (see NetProbe). */
    interface Net {
        int OK = 0, OFFLINE = 1, NEED_WIFI = 2;
        int check(boolean wifiOnly);
    }

    /** Non-retryable failure. */
    static final class Fatal extends IOException {
        final int code;
        Fatal(int code, String msg) { super(msg); this.code = code; }
    }

    /** Connection dropped on purpose because the allowed network went away (not counted as a failure). */
    private static final class NetGone extends IOException {
        NetGone() { super("เครือข่ายเปลี่ยน/หลุด"); }
    }

    static final class Task {
        final long id;
        final File target, part, src;
        final String url, token, title;
        volatile boolean wifiOnly, cancelled;
        volatile int status = PENDING, reason = 0;
        volatile long bytes = 0, total = -1;
        volatile String error = "";
        volatile HttpURLConnection conn;

        Task(long id, File target, String url, String token, boolean wifiOnly, String title) {
            this.id = id;
            this.target = target;
            this.part = new File(target.getParentFile(), target.getName() + ".part");
            this.src = new File(target.getParentFile(), target.getName() + ".part.src");
            this.url = url;
            this.token = token == null ? "" : token;
            this.wifiOnly = wifiOnly;
            this.title = title;
        }

        boolean active() { return status != SUCCESSFUL && status != FAILED; }
    }

    static final class Summary {
        int active, running, waitReason;
        long bytes, total;
    }

    // ---------- singleton ----------
    private static FileDownloader instance;

    static synchronized FileDownloader get(Net net) {
        if (instance == null) instance = new FileDownloader(net);
        return instance;
    }

    static synchronized FileDownloader peek() { return instance; }

    // ---------- tunables (package-private so tests can shorten them) ----------
    int maxRetry = 6;
    long retryBaseMs = 2000, pollMs = 1000, netCheckMs = 1000;
    long minFreeBytes = 32L * 1024 * 1024;
    int connectTimeoutMs = 20000, readTimeoutMs = 30000;
    boolean httpsOnly = true;

    private final Net net;
    private final ConcurrentHashMap<String, Task> tasks = new ConcurrentHashMap<String, Task>();
    private final ExecutorService pool;
    private long nextId = 1;
    volatile int doneCount, failCount;

    FileDownloader(Net net) {
        this.net = net;
        this.pool = Executors.newFixedThreadPool(3, new ThreadFactory() {
            private int n = 0;
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "rph-dl-" + (++n));
                t.setDaemon(true);
                return t;
            }
        });
    }

    // ---------- public API ----------
    /** Starts (or resumes) a download. If the same file is already running only its network rule is updated. */
    synchronized Task start(File target, String url, String token, boolean wifiOnly, String title) {
        String key = target.getAbsolutePath();
        Task old = tasks.get(key);
        if (old != null && old.active()) {
            old.wifiOnly = wifiOnly;
            return old;
        }
        File dir = target.getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();
        Task t = new Task(nextId++, target, url, token, wifiOnly, title);
        // A leftover partial file is only reused when it came from the same URL.
        String prev = readSrc(t.src);
        if (t.part.exists() && !url.equals(prev)) t.part.delete();
        writeSrc(t.src, url);
        tasks.put(key, t);
        final Task job = t;
        pool.execute(new Runnable() { @Override public void run() { FileDownloader.this.run(job); } });
        return t;
    }

    Task find(File target) { return tasks.get(target.getAbsolutePath()); }

    /** Stops a download and removes its partial file (a finished file with the same name is left alone). */
    synchronized void cancel(File target) {
        Task t = tasks.remove(target.getAbsolutePath());
        if (t != null) {
            t.cancelled = true;
            abort(t);
        }
        File dir = target.getParentFile();
        new File(dir, target.getName() + ".part").delete();
        new File(dir, target.getName() + ".part.src").delete();
    }

    /** All tasks (any state) whose file lives directly in dir. */
    List<Task> tasks(File dir) {
        List<Task> out = new ArrayList<Task>();
        for (Task t : tasks.values()) {
            File p = t.target.getParentFile();
            if (p != null && p.equals(dir)) out.add(t);
        }
        return out;
    }

    /** Changes the "Wi-Fi only" rule of every unfinished download in dir. */
    void setWifiOnly(File dir, boolean wifiOnly) {
        for (Task t : tasks(dir)) if (t.active()) t.wifiOnly = wifiOnly;
    }

    Summary summary() {
        Summary s = new Summary();
        for (Task t : tasks.values()) {
            if (!t.active()) continue;
            s.active++;
            if (t.status == RUNNING) s.running++;
            if (t.status == PAUSED && s.waitReason == 0) s.waitReason = t.reason;
            s.bytes += t.bytes;
            s.total += Math.max(t.total, t.bytes);
        }
        return s;
    }

    // ---------- worker ----------
    private void run(Task t) {
        int fails = 0;
        try {
            while (!t.cancelled) {
                int n = net.check(t.wifiOnly);
                if (n != Net.OK) {
                    pause(t, n == Net.NEED_WIFI ? WAIT_WIFI : WAIT_NETWORK, "");
                    if (!nap(pollMs, t)) return;
                    continue;
                }
                long before = t.bytes;
                try {
                    transfer(t);
                    complete(t);
                    return;
                } catch (Fatal f) {
                    if (!t.cancelled) fail(t, f.code, f.getMessage());
                    return;
                } catch (NetGone g) {
                    // loop again: the gate above decides whether to wait
                } catch (IOException e) {
                    if (t.cancelled) return;
                    if (isNoSpace(e)) { fail(t, ERR_SPACE, "พื้นที่ว่างไม่พอ"); return; }
                    if (t.bytes > before) fails = 0;
                    fails++;
                    String why = explain(e);
                    if (fails >= maxRetry) { fail(t, ERR_IO, why); return; }
                    pause(t, WAIT_RETRY, why + " · ลองใหม่ " + fails + "/" + maxRetry);
                    if (!nap(Math.min(retryBaseMs * fails, 10000L), t)) return;
                }
            }
        } catch (Throwable e) {
            if (!t.cancelled) fail(t, ERR_IO, explain(e));
        }
    }

    private void transfer(Task t) throws IOException {
        t.status = RUNNING;
        t.reason = 0;
        t.error = "";
        File dir = t.part.getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();
        long have = t.part.isFile() ? t.part.length() : 0;
        t.bytes = have;

        URL u = new URL(t.url);
        final String origHost = u.getHost();
        HttpURLConnection c;
        int code;
        for (int hop = 0; ; hop++) {
            if (hop > 8) throw new Fatal(ERR_HTTP, "ลิงก์ถูกเปลี่ยนเส้นทางวนซ้ำ");
            c = (HttpURLConnection) u.openConnection();
            t.conn = c;
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(connectTimeoutMs);
            c.setReadTimeout(readTimeoutMs);
            c.setRequestProperty("User-Agent", "RaphaelApp/14.1");
            c.setRequestProperty("Accept-Encoding", "identity"); // no transparent gzip: sizes / ranges stay exact
            if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
            if (t.token.length() > 0 && u.getHost().equalsIgnoreCase(origHost))
                c.setRequestProperty("Authorization", "Bearer " + t.token); // never forwarded to the CDN host
            if (t.cancelled) { c.disconnect(); throw new IOException("cancelled"); }
            code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null || loc.length() == 0) throw new Fatal(ERR_HTTP, "HTTP " + code + " แต่ไม่มีปลายทาง");
                u = new URL(u, loc);
                if (httpsOnly && !"https".equalsIgnoreCase(u.getProtocol()))
                    throw new Fatal(ERR_HTTP, "ลิงก์ถูกส่งต่อไปเป็นแบบไม่ปลอดภัย (http) จึงไม่โหลดให้");
                continue;
            }
            break;
        }

        try {
            boolean append;
            long total;
            if (code == 206) {
                long[] cr = parseRange(c.getHeaderField("Content-Range"));
                if (cr == null || cr[0] != have) {
                    discardPart(t);
                    throw new IOException("เซิร์ฟเวอร์ต่อไฟล์เดิมไม่ได้ · เริ่มโหลดใหม่");
                }
                total = cr[2] > 0 ? cr[2] : (c.getContentLengthLong() > 0 ? have + c.getContentLengthLong() : -1);
                append = true;
            } else if (code == 200) {
                long cl = c.getContentLengthLong();
                total = cl > 0 ? cl : -1;
                append = false; // fresh start, or the server ignored our Range header
            } else if (code == 416) {
                long[] cr = parseRange(c.getHeaderField("Content-Range"));
                if (have > 0 && cr != null && cr[2] == have) { t.total = have; return; } // already complete
                discardPart(t);
                throw new IOException("ไฟล์ที่ค้างอยู่ใช้ต่อไม่ได้ · เริ่มโหลดใหม่");
            } else if (code == 429 || code >= 500) {
                throw new IOException("เซิร์ฟเวอร์ตอบ HTTP " + code);
            } else if (code == 404 || code == 410) {
                throw new Fatal(ERR_HTTP, "HTTP " + code + " · ไม่พบไฟล์ที่ลิงก์นี้ (ลิงก์อาจเสียหรือถูกย้าย)");
            } else if (code == 401 || code == 403) {
                throw new Fatal(ERR_HTTP, "HTTP " + code + " · ไม่มีสิทธิ์ดาวน์โหลดไฟล์นี้ (ต้องล็อกอิน/ใส่โทเคน)");
            } else {
                throw new Fatal(ERR_HTTP, "เซิร์ฟเวอร์ตอบ HTTP " + code);
            }

            String ct = c.getContentType();
            if (ct != null && ct.toLowerCase(Locale.ROOT).startsWith("text/html")
                    && !t.target.getName().toLowerCase(Locale.ROOT).endsWith(".html"))
                throw new Fatal(ERR_HTTP, "เซิร์ฟเวอร์ส่งหน้าเว็บมาแทนไฟล์ (อาจติดหน้าล็อกอิน Wi-Fi หรือถูกบล็อก)");

            t.total = total;
            if (!append) have = 0;
            if (total > 0 && dir != null) {
                long need = total - (append ? have : 0);
                long free = dir.getUsableSpace();
                if (free > 0 && free < need + minFreeBytes)
                    throw new Fatal(ERR_SPACE, "พื้นที่ว่างไม่พอ (ต้องการ ~" + (need / (1024 * 1024)) + " MB)");
            }

            InputStream in = c.getInputStream();
            FileOutputStream out = new FileOutputStream(t.part, append);
            try {
                t.bytes = have;
                byte[] buf = new byte[64 * 1024];
                long lastCheck = System.currentTimeMillis();
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (t.cancelled) throw new IOException("cancelled");
                    out.write(buf, 0, n);
                    t.bytes += n;
                    long now = System.currentTimeMillis();
                    if (now - lastCheck >= netCheckMs) {
                        lastCheck = now;
                        if (net.check(t.wifiOnly) != Net.OK) throw new NetGone();
                    }
                }
            } finally {
                try { in.close(); } catch (Throwable ignore) { }
                try { out.close(); } catch (Throwable ignore) { }
            }
            if (t.total > 0 && t.bytes != t.total)
                throw new IOException("ได้รับไฟล์ไม่ครบ (" + t.bytes + "/" + t.total + " ไบต์)");
        } finally {
            try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    private void complete(Task t) throws Fatal {
        synchronized (this) {
            if (t.cancelled) return;
            if (t.target.exists() && !t.target.delete()) throw new Fatal(ERR_FILE, "เขียนทับไฟล์เดิมไม่ได้");
            if (!t.part.renameTo(t.target)) throw new Fatal(ERR_FILE, "บันทึกไฟล์ไม่สำเร็จ");
            t.src.delete();
            t.bytes = t.target.length();
            t.total = t.bytes;
            t.status = SUCCESSFUL;
            t.reason = 0;
            t.error = "";
            tasks.remove(t.target.getAbsolutePath(), t);
            doneCount++;
        }
    }

    private synchronized void fail(Task t, int code, String msg) {
        if (t.cancelled) return;
        t.status = FAILED;
        t.reason = code;
        t.error = msg == null ? "" : msg;
        failCount++;
    }

    private void pause(Task t, int reason, String msg) {
        t.status = PAUSED;
        t.reason = reason;
        t.error = msg;
    }

    private boolean nap(long ms, Task t) {
        long end = System.currentTimeMillis() + ms;
        while (!t.cancelled && System.currentTimeMillis() < end) {
            try { Thread.sleep(Math.min(100, Math.max(1, end - System.currentTimeMillis()))); }
            catch (InterruptedException e) { return false; }
        }
        return !t.cancelled;
    }

    private void abort(Task t) {
        HttpURLConnection c = t.conn;
        if (c != null) try { c.disconnect(); } catch (Throwable ignore) { }
    }

    private void discardPart(Task t) {
        t.part.delete();
        t.bytes = 0;
    }

    // ---------- helpers ----------
    private static final Pattern RANGE = Pattern.compile("bytes\\s+(?:(\\d+)-(\\d+)|\\*)/(\\d+|\\*)");

    /** "bytes 100-199/500" -> {100,199,500} · "bytes * / 500" -> {-1,-1,500} · null when unreadable. */
    static long[] parseRange(String h) {
        if (h == null) return null;
        Matcher m = RANGE.matcher(h.trim());
        if (!m.find()) return null;
        try {
            long a = m.group(1) == null ? -1 : Long.parseLong(m.group(1));
            long b = m.group(2) == null ? -1 : Long.parseLong(m.group(2));
            long tot = "*".equals(m.group(3)) ? -1 : Long.parseLong(m.group(3));
            return new long[]{a, b, tot};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static boolean isNoSpace(Throwable e) {
        String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
        return m.contains("enospc") || m.contains("no space left");
    }

    static String explain(Throwable e) {
        if (e instanceof UnknownHostException) return "หาเซิร์ฟเวอร์ไม่เจอ (DNS) · ตรวจอินเทอร์เน็ต / VPN / Private DNS";
        if (e instanceof SocketTimeoutException) return "หมดเวลาเชื่อมต่อเซิร์ฟเวอร์";
        if (e instanceof ConnectException) return "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้";
        if (e instanceof SSLException) return "การเชื่อมต่อปลอดภัย (SSL) ล้มเหลว · ตรวจวันที่/เวลาเครื่อง หรือ Wi-Fi ที่ต้องล็อกอิน";
        String m = e.getMessage();
        return e.getClass().getSimpleName() + (m == null || m.length() == 0 ? "" : ": " + m);
    }

    private static String readSrc(File f) {
        try {
            if (!f.isFile()) return "";
            FileReader r = new FileReader(f);
            try {
                char[] b = new char[8192];
                int n = r.read(b);
                return n <= 0 ? "" : new String(b, 0, n);
            } finally { r.close(); }
        } catch (Throwable e) { return ""; }
    }

    private static void writeSrc(File f, String url) {
        try {
            FileWriter w = new FileWriter(f, false);
            try { w.write(url); } finally { w.close(); }
        } catch (Throwable ignore) { }
    }
}
