package app.raphael.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Foreground service that owns the MediaProjection. Android requires a foreground service of
 * type "mediaProjection" to be running BEFORE getMediaProjection() is called (Android 10+/14+).
 */
public class ScreenCaptureService extends Service {
    private static final String TAG = "RaphaelScreen";
    private static final String CHANNEL = "raphael_screen";
    private static final int NOTIF_ID = 4417;
    private static final int MAX_SIDE = 960;

    // Shared state read by the Capacitor plugin.
    static volatile ScreenCaptureService instance;
    static volatile boolean ready = false;
    static volatile String error = null;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private int curW, curH, dpi;
    private byte[] lastJpeg;
    volatile OverlayController overlay;
    private final Object lock = new Object();
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if ("stop".equals(intent.getAction())) { shutdown(); return START_NOT_STICKY; }
        error = null; ready = false;
        try {
            startAsForeground();
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            if (projection == null) throw new IllegalStateException("MediaProjection is null");
            // Android 14 requires a callback to be registered before creating a VirtualDisplay.
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(new Runnable() { @Override public void run() { shutdown(); } }); }
            }, main);
            int[] wh = targetSize();
            curW = wh[0]; curH = wh[1];
            reader = ImageReader.newInstance(curW, curH, PixelFormat.RGBA_8888, 2);
            display = projection.createVirtualDisplay("RaphaelScreen", curW, curH, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
            overlay = new OverlayController(this);
            overlay.create();
            instance = this;
            ready = true;
        } catch (Throwable t) {
            Log.e(TAG, "start failed", t);
            error = String.valueOf(t.getMessage());
            shutdown();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Raphael อ่านหน้าจอ", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, ScreenCaptureService.class).setAction("stop");
        int pf = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent pi = PendingIntent.getService(this, 0, stop, pf);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        b.setContentIntent(PendingIntent.getActivity(this, 1, open, pf));
        b.setContentTitle("Raphael กำลังอ่านหน้าจอ")
         .setContentText("แตะ “หยุด” เพื่อปิดการอ่านหน้าจอ")
         .setSmallIcon(android.R.drawable.ic_menu_view)
         .setOngoing(true)
         .addAction(new Notification.Action.Builder(
                 android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause), "หยุด", pi).build());
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, 0x00000020 /* FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION */);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private int[] targetSize() {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);
        dpi = m.densityDpi;
        float k = Math.min(1f, MAX_SIDE / (float) Math.max(m.widthPixels, m.heightPixels));
        int w = Math.max(2, (int) (m.widthPixels * k)) & ~1;
        int h = Math.max(2, (int) (m.heightPixels * k)) & ~1;
        return new int[]{w, h};
    }

    /** Returns a JPEG of the newest frame (or the previous one if the screen has not changed). */
    byte[] captureJpeg() {
        synchronized (lock) {
            if (reader == null || display == null) return null;
            try {
                int[] wh = targetSize();
                if (wh[0] != curW || wh[1] != curH) { // rotated / resized: reuse the same VirtualDisplay
                    ImageReader old = reader;
                    curW = wh[0]; curH = wh[1];
                    reader = ImageReader.newInstance(curW, curH, PixelFormat.RGBA_8888, 2);
                    display.resize(curW, curH, dpi);
                    display.setSurface(reader.getSurface());
                    old.close();
                    try { Thread.sleep(150); } catch (InterruptedException ignored) {}
                }
                Image img = reader.acquireLatestImage();
                if (img == null) return lastJpeg;
                try {
                    Image.Plane p = img.getPlanes()[0];
                    ByteBuffer buf = p.getBuffer();
                    int px = p.getPixelStride(), rs = p.getRowStride();
                    Bitmap full = Bitmap.createBitmap(rs / px, img.getHeight(), Bitmap.Config.ARGB_8888);
                    full.copyPixelsFromBuffer(buf);
                    Bitmap crop = Bitmap.createBitmap(full, 0, 0, img.getWidth(), img.getHeight());
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    crop.compress(Bitmap.CompressFormat.JPEG, 60, out);
                    if (crop != full) full.recycle();
                    crop.recycle();
                    lastJpeg = out.toByteArray();
                } finally { img.close(); }
                return lastJpeg;
            } catch (Throwable t) {
                Log.e(TAG, "capture failed", t);
                return lastJpeg;
            }
        }
    }

    private void shutdown() {
        ready = false; instance = null;
        if (overlay != null) { overlay.remove(); overlay = null; }
        synchronized (lock) {
            try { if (display != null) display.release(); } catch (Throwable ignored) {}
            try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
            try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
            display = null; reader = null; projection = null; lastJpeg = null;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { ready = false; instance = null; super.onDestroy(); }

    static void requestStop(Context c) {
        final ScreenCaptureService s = instance;
        if (s != null) s.main.post(new Runnable() { @Override public void run() { s.shutdown(); } });
    }
}
