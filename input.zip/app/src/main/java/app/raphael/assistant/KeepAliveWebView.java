package app.raphael.assistant;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/**
 * Keeps the page "visible" to Chromium while the screen-watch (floating orb) is running, so JS timers
 * are not throttled. When screen-watch is OFF the WebView behaves normally and Chromium stops rendering
 * in the background (saves battery and removes the lag when coming back). The app learns about
 * foreground/background from window.__rphBg, which MainActivity sets in onStart/onStop.
 */
class KeepAliveWebView extends WebView {
    KeepAliveWebView(Context c) { super(c); }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (visibility != View.GONE && ScreenCaptureService.ready) super.onWindowVisibilityChanged(View.VISIBLE);
        else super.onWindowVisibilityChanged(visibility);
    }
}
