package app.raphael.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;

import org.json.JSONObject;

/**
 * Reads the state of the sensitive system permissions Raphael can use and opens the matching system
 * settings screen. Nothing here grants a permission by itself: the user always confirms in Android.
 */
class AccessManager {
    static final int REQ_STORAGE = 4406;

    /** True when this app's component appears in a ':'-separated "enabled services" secure setting. */
    private static boolean listed(Context c, String key, Class<?> cls) {
        String flat = Settings.Secure.getString(c.getContentResolver(), key);
        if (flat == null || flat.length() == 0) return false;
        ComponentName me = new ComponentName(c, cls);
        TextUtils.SimpleStringSplitter sp = new TextUtils.SimpleStringSplitter(':');
        sp.setString(flat);
        while (sp.hasNext()) {
            ComponentName cn = ComponentName.unflattenFromString(sp.next());
            if (me.equals(cn)) return true;
        }
        return false;
    }

    static JSONObject status(Activity a) throws Exception {
        JSONObject o = new JSONObject();
        String pkg = a.getPackageName();
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("a11y", listed(a, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, RaphaelAccessibilityService.class));
        o.put("listener", listed(a, "enabled_notification_listeners", RaphaelNotificationListener.class));

        NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
        o.put("notif", nm != null && nm.areNotificationsEnabled());

        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) a.getSystemService(Context.ALARM_SERVICE);
            exact = am != null && am.canScheduleExactAlarms();
        }
        o.put("exact", exact);

        o.put("overlay", OverlayController.canDraw(a));

        PowerManager pm = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
        o.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(pkg));

        boolean files;
        if (Build.VERSION.SDK_INT >= 30) files = Environment.isExternalStorageManager();
        else files = a.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        o.put("files", files);
        return o;
    }

    private static Intent details(Activity a) {
        return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName()));
    }

    /** Must be called on the UI thread. */
    static void open(Activity a, String target) {
        String pkg = a.getPackageName();
        Uri pu = Uri.parse("package:" + pkg);
        Intent i;
        switch (target) {
            case "a11y":
                i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                break;
            case "listener":
                i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                break;
            case "notif":
                if (Build.VERSION.SDK_INT >= 26) {
                    i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                } else {
                    i = details(a);
                }
                break;
            case "exact":
                i = Build.VERSION.SDK_INT >= 31 ? new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pu) : details(a);
                break;
            case "overlay":
                i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pu);
                break;
            case "battery": {
                PowerManager pm = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
                    i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pu);
                } else {
                    i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                }
                break;
            }
            case "files":
                if (Build.VERSION.SDK_INT >= 30) {
                    i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pu);
                } else {
                    a.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                    return;
                }
                break;
            case "appinfo":
                i = details(a);
                break;
            default:
                throw new IllegalArgumentException("unknown target " + target);
        }
        try {
            a.startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            a.startActivity(details(a)); // OEM without that screen: fall back to the app's info page
        }
    }
}
