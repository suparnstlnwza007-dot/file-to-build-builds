package app.raphael.assistant;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Fires scheduled notifications (reminders, daily briefs). */
public class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL = "raphael_reminders";
    static final String EXTRA_ID = "id", EXTRA_TITLE = "title", EXTRA_BODY = "body", EXTRA_DAILY = "daily";

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Raphael แจ้งเตือน", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    static PendingIntent pending(Context c, int id, String title, String body, boolean daily) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("app.raphael.assistant.REMINDER." + id);
        i.putExtra(EXTRA_ID, id).putExtra(EXTRA_TITLE, title).putExtra(EXTRA_BODY, body).putExtra(EXTRA_DAILY, daily);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, id, i, f);
    }

    static void schedule(Context c, int id, String title, String body, long atMs, boolean daily) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, id, title, body, daily);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, atMs, pi);
        }
    }

    static void cancel(Context c, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c, id, "", "", false));
    }

    @Override
    public void onReceive(Context c, Intent i) {
        int id = i.getIntExtra(EXTRA_ID, 0);
        String title = i.getStringExtra(EXTRA_TITLE), body = i.getStringExtra(EXTRA_BODY);
        boolean daily = i.getBooleanExtra(EXTRA_DAILY, false);
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent contentPi = PendingIntent.getActivity(c, id, open, f);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setContentTitle(title == null ? "Raphael" : title).setContentText(body == null ? "" : body)
         .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
         .setSmallIcon(android.R.drawable.ic_popup_reminder).setAutoCancel(true).setContentIntent(contentPi);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(id, b.build());
        if (daily) schedule(c, id, title, body, System.currentTimeMillis() + 24L * 3600 * 1000, true);
    }
}
