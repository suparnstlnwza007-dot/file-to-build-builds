package app.raphael.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * JS <-> Java bridge. The page calls RaphaelNative.call(id, "Plugin.method", jsonArgs); the answer is
 * delivered back through window.__rphCb(id, ok, value) (see assets/native-shim.js).
 */
class NativeBridge {
    private final MainActivity act;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int projCallId = -1;
    private int notifCallId = -1;

    private final ModelManager models;
    private final ModelManager voices;
    private final SpeechController speech;
    private int saveCallId = -1;
    private String saveName, saveData, saveMime;

    NativeBridge(MainActivity a, WebView w) {
        act = a; web = w;
        speech = new SpeechController(a, w);
        models = new ModelManager(a);
        voices = new ModelManager(a, "voices", "raphael_voices", "Raphael · ดาวน์โหลดโมเดลเสียง",
                new String[]{".onnx", ".json", ".txt", ".bin"});
        // taps on the floating core's menu (stop / pause / interval) are handed to the web app
        OverlayController.menuHandler = menuHandler;
    }

    private final OverlayController.MenuHandler menuHandler = new OverlayController.MenuHandler() {
        @Override public void onAction(String action, int value) {
            final String js = "try{window.__ovAct&&window.__ovAct(" + JSONObject.quote(action) + "," + value + ")}catch(e){}";
            ui.post(new Runnable() {
                @Override public void run() {
                    try { web.evaluateJavascript(js, null); } catch (Throwable ignored) { }
                }
            });
        }
    };

    // ---------- replies ----------
    private void send(final int id, final boolean ok, final String jsonValue) {
        ui.post(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window.__rphCb(" + id + "," + ok + "," + jsonValue + ")", null);
            }
        });
    }
    private void resolve(int id, JSONObject o) { send(id, true, o == null ? "null" : o.toString()); }
    private void reject(int id, String msg) { send(id, false, JSONObject.quote(msg == null ? "error" : msg)); }

    void setBackground(final boolean bg) {
        ui.post(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window.__rphBg=" + bg + ";try{window.dispatchEvent(new Event('rphbg'))}catch(e){}", null);
            }
        });
    }

    // ---------- entry point ----------
    @JavascriptInterface
    public void call(final int id, final String name, final String json) {
        JSONObject a;
        try { a = new JSONObject(json == null || json.length() == 0 ? "{}" : json); } catch (Exception e) { a = new JSONObject(); }
        final JSONObject args = a;
        try {
            switch (name) {
                case "RaphaelScreen.getInfo": getInfo(id); break;
                case "RaphaelScreen.overlayPermission": overlayPermission(id); break;
                case "RaphaelScreen.start": start(id); break;
                case "RaphaelScreen.stop": ScreenCaptureService.requestStop(act); resolve(id, null); break;
                case "RaphaelScreen.isRunning": { JSONObject o = new JSONObject(); o.put("running", ScreenCaptureService.ready); resolve(id, o); break; }
                case "RaphaelScreen.capture": capture(id); break;
                case "RaphaelScreen.overlayFrame": overlayFrame(id, args); break;
                case "RaphaelScreen.overlayText": {
                    ScreenCaptureService s = ScreenCaptureService.instance;
                    if (s != null && s.overlay != null) s.overlay.setText(args.optString("text", ""));
                    resolve(id, null); break;
                }
                case "RaphaelScreen.overlayVisible": {
                    ScreenCaptureService s = ScreenCaptureService.instance;
                    if (s != null && s.overlay != null) s.overlay.setVisible(args.optBoolean("visible", true));
                    resolve(id, null); break;
                }
                case "RaphaelScreen.overlayMenu": {
                    ScreenCaptureService s = ScreenCaptureService.instance;
                    if (s != null && s.overlay != null) s.overlay.setMenu(args);
                    resolve(id, null); break;
                }
                case "RaphaelScreen.goHome": goHome(id); break;
                case "LocalNotifications.requestPermissions": notifPermission(id); break;
                case "LocalNotifications.checkExactNotificationSetting": { JSONObject o = new JSONObject(); o.put("exact_alarm", "granted"); resolve(id, o); break; }
                case "LocalNotifications.changeExactNotificationSetting": resolve(id, null); break;
                case "LocalNotifications.schedule": schedule(id, args); break;
                case "LocalNotifications.cancel": cancel(id, args); break;
                case "Speech.available": { JSONObject o = new JSONObject(); o.put("available", speech.available()); resolve(id, o); break; }
                case "Speech.start": speechStart(id, args); break;
                case "Speech.stop": ui.post(new Runnable() { @Override public void run() { speech.stop(); } }); resolve(id, null); break;
                case "Speech.cancel": ui.post(new Runnable() { @Override public void run() { speech.cancel(); } }); resolve(id, null); break;
                case "Files.saveDownload": saveDownload(id, args); break;
                case "System.setBars": setBars(id, args.optBoolean("hidden", true)); break;
                case "System.getBars": { JSONObject o = new JSONObject(); o.put("hidden", act.barsHidden()); resolve(id, o); break; }
                case "Access.status": resolve(id, AccessManager.status(act)); break;
                case "Access.open": accessOpen(id, args.optString("target", "")); break;
                default:
                    if (name.startsWith("Models.")) resolve(id, models.handle(name, args));
                    else if (name.startsWith("Voices.")) resolve(id, voices.handle(name, args));
                    else reject(id, "unknown method " + name);
            }
        } catch (Throwable t) {
            reject(id, String.valueOf(t));
        }
    }

    // ---------- RaphaelScreen ----------
    private void getInfo(int id) throws Exception {
        JSONObject o = new JSONObject();
        o.put("version", "java-1");
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("overlay", OverlayController.canDraw(act));
        o.put("running", ScreenCaptureService.ready);
        resolve(id, o);
    }

    private void overlayPermission(final int id) throws Exception {
        boolean ok = OverlayController.canDraw(act);
        if (!ok) {
            ui.post(new Runnable() {
                @Override public void run() {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                }
            });
        }
        JSONObject o = new JSONObject();
        o.put("granted", ok);
        resolve(id, o);
    }

    private void start(final int id) {
        if (ScreenCaptureService.ready) { resolve(id, null); return; }
        ui.post(new Runnable() {
            @Override public void run() {
                projCallId = id;
                MediaProjectionManager mpm = (MediaProjectionManager) act.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                act.startActivityForResult(mpm.createScreenCaptureIntent(), MainActivity.REQ_PROJECTION);
            }
        });
    }

    void onProjectionResult(int resultCode, Intent data) {
        int id = projCallId;
        projCallId = -1;
        if (id < 0) return;
        if (resultCode != Activity.RESULT_OK || data == null) { reject(id, "ไม่ได้รับอนุญาตให้จับภาพหน้าจอ"); return; }
        Intent i = new Intent(act, ScreenCaptureService.class);
        i.putExtra("code", resultCode);
        i.putExtra("data", data);
        if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i); else act.startService(i);
        waitReady(id, 0);
    }

    private void waitReady(final int id, final int tries) {
        if (ScreenCaptureService.ready) { resolve(id, null); return; }
        if (ScreenCaptureService.error != null) { reject(id, "เริ่มจับภาพหน้าจอไม่สำเร็จ: " + ScreenCaptureService.error); return; }
        if (tries > 50) { reject(id, "เริ่มจับภาพหน้าจอไม่ทัน (หมดเวลา)"); return; }
        ui.postDelayed(new Runnable() { @Override public void run() { waitReady(id, tries + 1); } }, 100);
    }

    private void capture(final int id) {
        final ScreenCaptureService s = ScreenCaptureService.instance;
        if (s == null || !ScreenCaptureService.ready) { reject(id, "ยังไม่ได้เริ่มอ่านหน้าจอ"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    byte[] jpg = s.captureJpeg();
                    if (jpg == null) { reject(id, "ยังไม่มีภาพหน้าจอ"); return; }
                    JSONObject o = new JSONObject();
                    o.put("data", Base64.encodeToString(jpg, Base64.NO_WRAP));
                    resolve(id, o);
                } catch (Throwable t) { reject(id, String.valueOf(t)); }
            }
        }).start();
    }

    private void overlayFrame(int id, JSONObject args) {
        ScreenCaptureService s = ScreenCaptureService.instance;
        if (s == null || !ScreenCaptureService.ready) { reject(id, "not running"); return; }
        String b = args.optString("png", null);
        OverlayController ov = s.overlay;
        if (b != null && b.length() > 0 && ov != null) {
            try { ov.setFrame(Base64.decode(b, Base64.DEFAULT)); } catch (Throwable ignored) {}
        }
        resolve(id, null);
    }

    private void goHome(final int id) {
        ui.post(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                try { ok = act.moveTaskToBack(true); } catch (Throwable ignored) {}
                if (!ok) {
                    Intent h = new Intent(Intent.ACTION_MAIN);
                    h.addCategory(Intent.CATEGORY_HOME);
                    h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(h);
                }
                resolve(id, null);
            }
        });
    }

    // ---------- Speech (voice input) ----------
    private void speechStart(final int id, final JSONObject args) {
        final String lang = args.optString("lang", "");
        final boolean partial = args.optBoolean("partial", true);
        ui.post(new Runnable() {
            @Override public void run() { speech.start(lang, partial); resolve(id, null); }
        });
    }

    void onMicResult(boolean ok) { speech.onPermission(ok); }

    // ---------- Files: save into Downloads ----------
    private void saveDownload(final int id, final JSONObject args) {
        final String name = args.optString("name", ""), data = args.optString("data", ""), mime = args.optString("mime", "application/json");
        if (FileSaver.needsLegacyPermission()
                && act.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ui.post(new Runnable() {
                @Override public void run() {
                    saveCallId = id; saveName = name; saveData = data; saveMime = mime;
                    act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MainActivity.REQ_STORAGE);
                }
            });
            return;
        }
        doSave(id, name, data, mime, true);
    }

    private void doSave(final int id, final String name, final String data, final String mime, final boolean pub) {
        new Thread(new Runnable() {
            @Override public void run() {
                try { resolve(id, FileSaver.save(act, name, data, mime, pub)); }
                catch (Throwable t) { reject(id, String.valueOf(t.getMessage() != null ? t.getMessage() : t)); }
            }
        }).start();
    }

    void onStorageResult(boolean granted) {
        int id = saveCallId;
        saveCallId = -1;
        if (id < 0) return;
        // denied -> still save, but in the app's own folder so the backup is never lost
        doSave(id, saveName, saveData, saveMime, granted);
        saveName = saveData = saveMime = null;
    }

    // ---------- System bars ----------
    private void setBars(final int id, final boolean hidden) {
        ui.post(new Runnable() {
            @Override public void run() { act.setBarsHidden(hidden); resolve(id, null); }
        });
    }

    void destroy() {
        if (OverlayController.menuHandler == menuHandler) OverlayController.menuHandler = null;
        speech.destroy();
    }
    void pauseSpeech() { speech.cancel(); }

    // ---------- Access (sensitive system permissions) ----------
    private void accessOpen(final int id, final String target) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    AccessManager.open(act, target);
                    resolve(id, null);
                } catch (Throwable t) {
                    reject(id, String.valueOf(t));
                }
            }
        });
    }

    // ---------- LocalNotifications ----------
    private void notifPermission(final int id) throws Exception {
        if (Build.VERSION.SDK_INT >= 33 && act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ui.post(new Runnable() {
                @Override public void run() {
                    notifCallId = id;
                    act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, MainActivity.REQ_NOTIF);
                }
            });
        } else {
            JSONObject o = new JSONObject();
            o.put("display", "granted");
            resolve(id, o);
        }
    }

    void onNotifResult(boolean granted) {
        int id = notifCallId;
        notifCallId = -1;
        if (id < 0) return;
        try { JSONObject o = new JSONObject(); o.put("display", granted ? "granted" : "denied"); resolve(id, o); }
        catch (Exception e) { reject(id, String.valueOf(e)); }
    }

    private void schedule(int id, JSONObject args) throws Exception {
        JSONArray arr = args.optJSONArray("notifications");
        if (arr != null) {
            for (int k = 0; k < arr.length(); k++) {
                JSONObject n = arr.getJSONObject(k);
                long at = n.optLong("at", 0);
                if (at <= 0) continue;
                ReminderReceiver.ensureChannel(act);
                ReminderReceiver.schedule(act, n.optInt("id"), n.optString("title", "Raphael"), n.optString("body", ""), at, n.optBoolean("daily", false));
            }
        }
        resolve(id, null);
    }

    private void cancel(int id, JSONObject args) throws Exception {
        JSONArray arr = args.optJSONArray("notifications");
        if (arr != null) for (int k = 0; k < arr.length(); k++) ReminderReceiver.cancel(act, arr.getJSONObject(k).optInt("id"));
        resolve(id, null);
    }
}
