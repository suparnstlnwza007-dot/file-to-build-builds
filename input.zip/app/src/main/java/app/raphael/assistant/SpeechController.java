package app.raphael.assistant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Voice input through Android's SpeechRecognizer (WebView has no SpeechRecognition).
 * All methods must run on the main thread. Events go to window.__rphSp(kind, payload):
 *   start | partial {text} | final {text} | error {error} | end
 * The shim in native-shim.js turns these into a SpeechRecognition-compatible class.
 */
class SpeechController {
    private final MainActivity act;
    private final WebView web;
    private SpeechRecognizer rec;
    private String pendingLang;
    private boolean pendingPartial;
    private boolean gotFinal;
    private boolean ending;   // stop()/cancel() requested -> suppress duplicate "end"

    SpeechController(MainActivity a, WebView w) { act = a; web = w; }

    boolean available() { return SpeechRecognizer.isRecognitionAvailable(act); }

    void start(String lang, boolean partial) {
        if (!available()) { emit("error", "{\"error\":\"unavailable\"}"); emit("end", "null"); return; }
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang; pendingPartial = partial;
            act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.REQ_MIC);
            return;
        }
        begin(lang, partial);
    }

    void onPermission(boolean ok) {
        if (ok) { begin(pendingLang, pendingPartial); }
        else { emit("error", "{\"error\":\"not-allowed\"}"); emit("end", "null"); }
        pendingLang = null;
    }

    private void begin(String lang, boolean partial) {
        destroy();
        gotFinal = false; ending = false;
        try {
            rec = SpeechRecognizer.createSpeechRecognizer(act);
            rec.setRecognitionListener(new Listener());
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            if (lang != null && lang.length() > 0) {
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
            }
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.getPackageName());
            rec.startListening(i);
        } catch (Throwable t) {
            destroy();
            emit("error", "{\"error\":\"audio-capture\"}");
            emit("end", "null");
        }
    }

    /** Stop listening but still deliver what was heard so far. */
    void stop() {
        if (rec == null) return;
        try { rec.stopListening(); } catch (Throwable ignored) {}
    }

    /** Abort: drop the session and report "end" once. */
    void cancel() {
        if (rec == null) return;
        ending = true;
        destroy();
        emit("end", "null");
    }

    void destroy() {
        SpeechRecognizer r = rec;
        rec = null;
        if (r != null) {
            try { r.setRecognitionListener(null); } catch (Throwable ignored) {}
            try { r.cancel(); } catch (Throwable ignored) {}
            try { r.destroy(); } catch (Throwable ignored) {}
        }
    }

    private static String firstText(Bundle b) {
        if (b == null) return "";
        ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l == null || l.isEmpty() || l.get(0) == null) ? "" : l.get(0);
    }

    private static String errName(int e) {
        switch (e) {
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "not-allowed";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "no-speech";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
            case SpeechRecognizer.ERROR_SERVER: return "network";
            case SpeechRecognizer.ERROR_AUDIO: return "audio-capture";
            case SpeechRecognizer.ERROR_CLIENT: return "aborted";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "busy";
            case 12: /* ERROR_LANGUAGE_NOT_SUPPORTED */
            case 13: /* ERROR_LANGUAGE_UNAVAILABLE */ return "language-not-supported";
            default: return "unknown";
        }
    }

    private void emit(final String kind, final String payload) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window.__rphSp&&window.__rphSp(" + JSONObject.quote(kind) + "," + payload + ")", null);
            }
        });
    }

    private static String textJson(String t) {
        try { return new JSONObject().put("text", t).toString(); } catch (Exception e) { return "{\"text\":\"\"}"; }
    }

    private class Listener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle p) { emit("start", "null"); }
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onEvent(int t, Bundle p) {}

        @Override public void onPartialResults(Bundle b) {
            String t = firstText(b);
            if (t.length() > 0) emit("partial", textJson(t));
        }

        @Override public void onResults(Bundle b) {
            gotFinal = true;
            emit("final", textJson(firstText(b)));
            emit("end", "null");
            destroy();
        }

        @Override public void onError(int e) {
            if (ending) return;
            emit("error", "{\"error\":\"" + errName(e) + "\"}");
            emit("end", "null");
            destroy();
        }
    }
}
