package app.raphael.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String ORIGIN = "https://" + HOST + "/";
    static final int REQ_PROJECTION = 4401, REQ_FILE = 4402, REQ_WEBPERM = 4403, REQ_NOTIF = 4404, REQ_GEO = 4405, REQ_CAMPERM = 4406, REQ_CAMSHOT = 4407, REQ_MIC = 4408, REQ_STORAGE = 4409;

    private KeepAliveWebView web;
    private NativeBridge bridge;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingWebPerm;
    private GeolocationPermissions.Callback pendingGeoCb;
    private String pendingGeoOrigin;
    private byte[] indexCache;
    private WebChromeClient.FileChooserParams pendingCamParams;
    private File camFile;
    private Uri camUri;
    private final Handler ui = new Handler();
    private boolean hideBars = true;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        hideBars = getSharedPreferences("raphael", MODE_PRIVATE).getBoolean("hideBars", true);
        getWindow().setStatusBarColor(0xFF02050C);
        getWindow().setNavigationBarColor(0xFF02050C);
        web = new KeepAliveWebView(this);
        web.setBackgroundColor(0xFF020A1F);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setGeolocationEnabled(true);
        s.setSupportZoom(false);

        bridge = new NativeBridge(this, web);
        web.addJavascriptInterface(bridge, "RaphaelNative");
        web.setWebViewClient(new AssetClient());
        web.setWebChromeClient(new Chrome());
        web.loadUrl(ORIGIN + "index.html");
        hideSystemBars();
    }

    // ---------- hide status bar + navigation bar (immersive; swipe from the edge to peek) ----------
    boolean barsHidden() { return hideBars; }

    void setBarsHidden(boolean hidden) {
        if (hidden == hideBars) return;
        hideBars = hidden;
        getSharedPreferences("raphael", MODE_PRIVATE).edit().putBoolean("hideBars", hidden).apply();
        if (hidden) hideSystemBars(); else showSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void showSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) c.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        } else {
            View d = w.getDecorView();
            d.setOnSystemUiVisibilityChangeListener(null);
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        if (!hideBars) return;
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            final View d = w.getDecorView();
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
            d.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                @Override public void onSystemUiVisibilityChange(int v) {
                    if (hideBars && (v & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                        ui.postDelayed(new Runnable() { @Override public void run() { hideSystemBars(); } }, 1500);
                    }
                }
            });
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && hideBars) hideSystemBars();
    }

    // ---------- serving assets from https://appassets.androidplatform.net/ ----------
    private class AssetClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (!HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.equals("/") || path.length() == 0) path = "/index.html";
            String name = path.substring(1);
            try {
                if (name.equals("index.html")) {
                    return new WebResourceResponse("text/html", "utf-8", new ByteArrayInputStream(indexWithShim()));
                }
                InputStream in = getAssets().open(name);
                return new WebResourceResponse(mime(name), null, in);
            } catch (Exception e) {
                Map<String, String> h = new HashMap<String, String>();
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) {}
            return true;
        }
    }

    private byte[] indexWithShim() throws Exception {
        if (indexCache != null) return indexCache;
        String html = new String(readAll(getAssets().open("index.html")), Charset.forName("UTF-8"));
        String shim = new String(readAll(getAssets().open("native-shim.js")), Charset.forName("UTF-8"));
        int i = html.indexOf("<head>");
        String out = i >= 0 ? html.substring(0, i + 6) + "<script>" + shim + "</script>" + html.substring(i + 6)
                            : "<script>" + shim + "</script>" + html;
        indexCache = out.getBytes(Charset.forName("UTF-8"));
        return indexCache;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    private static String mime(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json") || n.endsWith(".webmanifest")) return "application/json";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".woff2")) return "font/woff2";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        String ext = MimeTypeMap.getFileExtensionFromUrl(name);
        String m = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? "application/octet-stream" : m;
    }

    // ---------- permissions, dialogs, file chooser ----------
    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (!HOST.equals(req.getOrigin().getHost())) { req.deny(); return; }
                    List<String> need = new ArrayList<String>();
                    for (String r : req.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA);
                    }
                    if (need.isEmpty()) { req.grant(req.getResources()); }
                    else { pendingWebPerm = req; requestPermissions(need.toArray(new String[0]), REQ_WEBPERM); }
                }
            });
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                cb.invoke(origin, true, false);
            } else {
                pendingGeoCb = cb; pendingGeoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }
        }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            // <input capture="..."> (camera button) -> open the camera app and take a photo
            if (wantsCamera(p)) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    pendingCamParams = p;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMPERM);
                    return true;
                }
                if (launchCamera()) return true;
            }
            return launchPicker(p);
        }
    }

    private boolean wantsCamera(WebChromeClient.FileChooserParams p) {
        if (p == null || !p.isCaptureEnabled()) return false;
        String[] a = p.getAcceptTypes();
        if (a == null || a.length == 0) return true;
        for (String s : a) if (s == null || s.length() == 0 || s.startsWith("image")) return true;
        return false;
    }

    private boolean launchPicker(WebChromeClient.FileChooserParams p) {
        try { startActivityForResult(p.createIntent(), REQ_FILE); return true; }
        catch (Exception e) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = null;
            return false;
        }
    }

    private boolean launchCamera() {
        try {
            File dir = CameraProvider.dir(this);
            File[] old = dir.listFiles();   // clear photos older than a day
            if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 86400000L) f.delete();
            camFile = new File(dir, "raphael_" + System.currentTimeMillis() + ".jpg");
            camUri = Uri.parse("content://" + CameraProvider.AUTH + "/cam/" + camFile.getName());
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            i.setClipData(ClipData.newRawUri("photo", camUri));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMSHOT);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        boolean ok = res.length > 0;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        if (code == REQ_WEBPERM && pendingWebPerm != null) {
            if (ok) pendingWebPerm.grant(pendingWebPerm.getResources()); else pendingWebPerm.deny();
            pendingWebPerm = null;
        } else if (code == REQ_GEO && pendingGeoCb != null) {
            pendingGeoCb.invoke(pendingGeoOrigin, ok, false);
            pendingGeoCb = null;
        } else if (code == REQ_CAMPERM) {
            WebChromeClient.FileChooserParams p = pendingCamParams;
            pendingCamParams = null;
            if (fileCb == null) return;
            if (!(ok && launchCamera())) {
                // no camera permission / no camera app: fall back to the normal picker
                if (p == null || !launchPicker(p)) { if (fileCb != null) fileCb.onReceiveValue(null); fileCb = null; }
            }
        } else if (code == REQ_NOTIF) {
            bridge.onNotifResult(ok);
        } else if (code == REQ_MIC) {
            bridge.onMicResult(ok);
        } else if (code == REQ_STORAGE) {
            bridge.onStorageResult(ok);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_PROJECTION) {
            bridge.onProjectionResult(res, data);
        } else if (req == REQ_CAMSHOT) {
            if (fileCb != null) {
                boolean got = res == RESULT_OK && camFile != null && camFile.length() > 0;
                fileCb.onReceiveValue(got ? new Uri[]{camUri} : null);
                fileCb = null;
            }
        } else if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    // ---------- lifecycle: tell the page when we are in the background ----------
    @Override protected void onStart() { super.onStart(); if (bridge != null) bridge.setBackground(false); }
    @Override protected void onStop() { super.onStop(); if (bridge != null) { bridge.setBackground(true); bridge.pauseSpeech(); } }
    @Override protected void onPause() { super.onPause(); if (web != null) web.resumeTimers(); }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (bridge != null) bridge.destroy();
        if (web != null) { web.removeJavascriptInterface("RaphaelNative"); web.destroy(); }
        super.onDestroy();
    }
}
