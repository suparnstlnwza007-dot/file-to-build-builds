package app.raphael.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

/**
 * Foreground service that keeps the process (and the CPU) alive while FileDownloader has unfinished downloads
 * and shows one progress notification. It owns no download logic: FileDownloader does the work in its own threads.
 * The service stops itself a couple of seconds after the last download ends.
 */
public class DownloadService extends Service {
    private static final String TAG = "RaphaelDownload";
    private static final String CHANNEL = "raphael_download";
    private static final int NOTIF_ID = 4418, DONE_ID = 4419;

    private final Handler main = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private int idleTicks = 0;
    private int doneAtStart = -1, failAtStart = -1;

    private final Runnable tick = new Runnable() {
        @Override public void run() { onTick(); }
    };

    /** Called by ModelManager after it queued a download. Never throws: if the service can't start, the download still runs. */
    static void ensure(Context c) {
        try {
            Intent i = new Intent(c.getApplicationContext(), DownloadService.class);
            if (Build.VERSION.SDK_INT >= 26) c.getApplicationContext().startForegroundService(i);
            else c.getApplicationContext().startService(i);
        } catch (Throwable t) {
            Log.w(TAG, "foreground service not started: " + t);
        }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        FileDownloader d = FileDownloader.peek();
        if (doneAtStart < 0 && d != null) { doneAtStart = d.doneCount; failAtStart = d.failCount; }
        try {
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "raphael:download");
                wl.setReferenceCounted(false);
                wl.acquire(6L * 60 * 60 * 1000);
            }
        } catch (Throwable t) {
            Log.w(TAG, "wakelock: " + t);
        }
        try {
            startAsForeground(build(d != null ? d.summary() : null));
        } catch (Throwable t) {
            // Android kills an app whose service was started with startForegroundService() but never became foreground,
            // so give up cleanly here; the downloads themselves keep running in FileDownloader's own threads.
            Log.w(TAG, "startForeground failed: " + t);
            release();
            stopSelf();
            return START_NOT_STICKY;
        }
        idleTicks = 0;
        main.removeCallbacks(tick);
        main.postDelayed(tick, 1000);
        return START_NOT_STICKY;
    }

    private void onTick() {
        FileDownloader d = FileDownloader.peek();
        FileDownloader.Summary s = d == null ? null : d.summary();
        if (s == null || s.active == 0) {
            if (++idleTicks >= 2) { finish(d); return; }
        } else {
            idleTicks = 0;
            try {
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, build(s));
            } catch (Throwable t) {
                Log.w(TAG, "notify: " + t);
            }
        }
        main.postDelayed(tick, 1000);
    }

    private void finish(FileDownloader d) {
        main.removeCallbacks(tick);
        try {
            if (d != null && doneAtStart >= 0) {
                int ok = d.doneCount - doneAtStart, bad = d.failCount - failAtStart;
                if (ok > 0 || bad > 0) postResult(ok, bad);
            }
        } catch (Throwable t) {
            Log.w(TAG, "result notification: " + t);
        }
        release();
        try { stopForeground(true); } catch (Throwable ignore) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(tick);
        release();
        super.onDestroy();
    }

    private void release() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignore) { }
        wl = null;
    }

    // ---------- notifications ----------
    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Raphael ดาวน์โหลดโมเดล", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private Notification.Builder builder() {
        ensureChannel();
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int pf = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        b.setContentIntent(PendingIntent.getActivity(this, 2, open, pf));
        return b;
    }

    private Notification build(FileDownloader.Summary s) {
        Notification.Builder b = builder();
        b.setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setOnlyAlertOnce(true);
        if (s == null || s.active == 0) {
            b.setContentTitle("Raphael · กำลังเตรียมดาวน์โหลด").setProgress(0, 0, true);
            return b.build();
        }
        b.setContentTitle("Raphael · ดาวน์โหลดโมเดล (" + s.active + " ไฟล์)");
        if (s.running == 0 && s.waitReason == FileDownloader.WAIT_WIFI) {
            b.setContentText("รอ Wi-Fi… (เปิด “ผ่าน Wi-Fi เท่านั้น” ไว้)").setProgress(0, 0, true);
        } else if (s.running == 0 && s.waitReason == FileDownloader.WAIT_NETWORK) {
            b.setContentText("ไม่มีสัญญาณอินเทอร์เน็ต · จะต่อให้เอง").setProgress(0, 0, true);
        } else if (s.total > 0) {
            int pct = (int) Math.min(100, s.bytes * 100 / s.total);
            b.setContentText(mb(s.bytes) + " / " + mb(s.total) + " (" + pct + "%)").setProgress(100, pct, false);
        } else {
            b.setContentText("กำลังเชื่อมต่อ…").setProgress(0, 0, true);
        }
        return b.build();
    }

    private void postResult(int ok, int bad) {
        Notification.Builder b = builder();
        b.setSmallIcon(bad > 0 && ok == 0 ? android.R.drawable.stat_notify_error : android.R.drawable.stat_sys_download_done)
         .setAutoCancel(true);
        if (bad > 0 && ok == 0) b.setContentTitle("Raphael · ดาวน์โหลดไม่สำเร็จ").setContentText("เปิดแอปเพื่อดูสาเหตุและลองใหม่");
        else if (bad > 0) b.setContentTitle("Raphael · ดาวน์โหลดเสร็จ " + ok + " ไฟล์").setContentText("มี " + bad + " ไฟล์ไม่สำเร็จ · เปิดแอปเพื่อลองใหม่");
        else b.setContentTitle("Raphael · ดาวน์โหลดเสร็จแล้ว").setContentText(ok + " ไฟล์ พร้อมใช้งาน");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(DONE_ID, b.build());
    }

    private void startAsForeground(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, 0x00000001 /* FOREGROUND_SERVICE_TYPE_DATA_SYNC */);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private static String mb(long b) {
        double m = b / 1048576.0;
        return m >= 1024 ? String.format(java.util.Locale.US, "%.2f GB", m / 1024) : Math.round(m) + " MB";
    }
}
