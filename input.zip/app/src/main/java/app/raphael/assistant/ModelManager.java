package app.raphael.assistant;

import android.app.ActivityManager;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Build;
import android.os.StatFs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

/**
 * Local file manager for downloadable AI files (language models in "models", voice models in "voices").
 * v14.1: downloads are done by the app itself (FileDownloader + DownloadService) instead of Android's
 * DownloadManager, which stalled at "waiting for network" on some phones. They still resume after a network
 * drop, keep running in the background and show a notification.
 * Files live in the app-private external dir (Android/data/app.raphael.assistant/files/<sub>),
 * which needs no storage permission and is removed when the app is uninstalled.
 */
class ModelManager {
    private final String sub;
    private final String[] exts;
    private final Context ctx;
    private final SharedPreferences sp;
    private final FileDownloader dl;
    private final NetProbe probe;

    /** Language models (.gguf etc.) in files/models. */
    ModelManager(Context c) {
        this(c, "models", "raphael_models", "Raphael · ดาวน์โหลดโมเดล",
                new String[]{".gguf", ".task", ".bin", ".tflite", ".litertlm"});
    }

    /** Generic: sub-folder under the app's external files dir, prefs file name, (unused) notification label, allowed extensions. */
    ModelManager(Context c, String sub, String pref, String label, String[] exts) {
        this.sub = sub;
        this.exts = exts;
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences(pref, Context.MODE_PRIVATE);
        probe = new NetProbe(ctx);
        dl = FileDownloader.get(probe);
        dropOldDownloadManagerJobs();
    }

    JSONObject handle(String name, JSONObject a) throws Exception {
        String m = name.substring(name.indexOf('.') + 1); // "Models.list" / "Voices.list" -> "list"
        switch (m) {
            case "device": return device();
            case "list": return list();
            case "download": return download(a);
            case "cancel": return cancel(a.optString("file"));
            case "delete": return delete(a.optString("file"));
            case "net": return net(a);
            default: throw new IllegalArgumentException("unknown method " + name);
        }
    }

    // ---------- helpers ----------
    private File dir() {
        File d = ctx.getExternalFilesDir(sub);
        if (d == null) d = new File(ctx.getFilesDir(), sub);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private boolean allowed(String lowerName) {
        for (String e : exts) if (lowerName.endsWith(e)) return true;
        return false;
    }

    /** Only plain file names with an allowed extension are accepted. */
    private String safeName(String f) {
        if (f == null) throw new IllegalArgumentException("missing file name");
        f = f.trim();
        if (f.length() == 0 || f.length() > 160 || f.contains("/") || f.contains("\\") || f.startsWith("."))
            throw new IllegalArgumentException("invalid file name");
        if (!allowed(f.toLowerCase(Locale.ROOT))) throw new IllegalArgumentException("unsupported file type");
        return f;
    }

    /**
     * Versions up to v14 queued downloads in Android's DownloadManager and remembered their ids as "dl.<file>".
     * A job stuck there ("waiting for network") would keep fighting over the same file name, so cancel
     * every leftover (DownloadManager also deletes its half-written file) and forget the ids.
     */
    private void dropOldDownloadManagerJobs() {
        try {
            SharedPreferences.Editor ed = null;
            for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
                String key = e.getKey();
                if (!key.startsWith("dl.")) continue;
                if (ed == null) ed = sp.edit();
                ed.remove(key);
                if (!(e.getValue() instanceof Long)) continue;
                long id = (Long) e.getValue();
                try {
                    DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
                    boolean complete = false;
                    Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
                    try {
                        if (c != null && c.moveToFirst())
                            complete = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL;
                    } finally {
                        if (c != null) c.close();
                    }
                    dm.remove(id);
                    if (!complete) new File(dir(), key.substring(3)).delete();
                } catch (Throwable ignore) { }
            }
            if (ed != null) ed.apply();
        } catch (Throwable ignore) { }
    }

    // ---------- device ----------
    private JSONObject device() throws Exception {
        JSONObject o = new JSONObject();
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        o.put("ramMB", mi.totalMem / (1024 * 1024));
        o.put("availRamMB", mi.availMem / (1024 * 1024));
        StatFs st = new StatFs(dir().getPath());
        o.put("freeMB", st.getAvailableBytes() / (1024 * 1024));
        o.put("totalMB", st.getTotalBytes() / (1024 * 1024));
        o.put("cores", Runtime.getRuntime().availableProcessors());
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
        o.put("abi64", Build.SUPPORTED_64_BIT_ABIS != null && Build.SUPPORTED_64_BIT_ABIS.length > 0);
        o.put("abi", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
        o.put("dir", dir().getAbsolutePath());
        o.put("net", probe.kind());
        return o;
    }

    // ---------- list (downloaded files + live download progress) ----------
    private JSONObject row(FileDownloader.Task t) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", t.id);
        o.put("file", t.target.getName());
        o.put("status", t.status);
        o.put("reason", t.reason);
        o.put("bytes", t.bytes);
        o.put("total", t.total);
        o.put("error", t.error);
        o.put("wifiOnly", t.wifiOnly);
        return o;
    }

    private JSONObject list() throws Exception {
        JSONArray files = new JSONArray();
        JSONArray active = new JSONArray();
        File d = dir();
        HashSet<String> pending = new HashSet<String>();

        // unfinished (or failed, until the user dismisses/retries them) downloads
        for (FileDownloader.Task t : dl.tasks(d)) {
            if (t.status == FileDownloader.SUCCESSFUL) continue;
            pending.add(t.target.getName());
            active.put(row(t));
        }
        File[] fs = d.listFiles();
        if (fs != null) {
            for (File f : fs) {
                if (!f.isFile() || pending.contains(f.getName())) continue;
                if (!allowed(f.getName().toLowerCase(Locale.ROOT))) continue; // also hides *.part / *.part.src
                if (f.length() == 0) continue;                                // empty leftover of an old stuck download
                JSONObject o = new JSONObject();
                o.put("file", f.getName());
                o.put("bytes", f.length());
                o.put("path", f.getAbsolutePath());
                files.put(o);
            }
        }
        JSONObject out = new JSONObject();
        out.put("files", files);
        out.put("active", active);
        return out;
    }

    // ---------- download / cancel / delete / net ----------
    private JSONObject download(JSONObject a) throws Exception {
        String url = a.optString("url", "").trim();
        String file = safeName(a.optString("file"));
        if (!url.startsWith("https://")) throw new IllegalArgumentException("ต้องเป็นลิงก์ https เท่านั้น");
        boolean wifiOnly = a.optBoolean("wifiOnly", true);
        File target = new File(dir(), file);

        JSONObject o = new JSONObject();
        FileDownloader.Task cur = dl.find(target);
        if (cur != null && cur.active()) {          // already running: only apply the new Wi-Fi rule
            cur.wifiOnly = wifiOnly;
            o.put("id", cur.id);
            o.put("already", true);
            return o;
        }

        long need = a.optLong("sizeMB", 0) * 1024L * 1024L;
        if (need > 0) {
            File part = new File(dir(), file + ".part");
            long have = part.isFile() ? part.length() : 0;
            StatFs st = new StatFs(dir().getPath());
            if (st.getAvailableBytes() < Math.max(0L, need - have) + 300L * 1024 * 1024)
                throw new IllegalStateException("พื้นที่ว่างไม่พอ (ต้องการ ~" + (need / (1024 * 1024)) + " MB + เผื่อ 300 MB)");
        }

        String tok = a.optString("token", "").trim();
        FileDownloader.Task t = dl.start(target, url, tok, wifiOnly, a.optString("title", file));
        DownloadService.ensure(ctx);
        String kind = probe.kind();
        o.put("id", t.id);
        o.put("net", kind);
        o.put("waitWifi", wifiOnly && "cell".equals(kind));
        return o;
    }

    private JSONObject cancel(String f) throws Exception {
        String file = safeName(f);
        File target = new File(dir(), file);
        dl.cancel(target);     // stops the transfer and removes the partial file
        target.delete();       // "clear files" also removes a finished file of the same name
        return new JSONObject();
    }

    private JSONObject delete(String f) throws Exception {
        String file = safeName(f);
        File target = new File(dir(), file);
        dl.cancel(target);
        boolean ok = target.delete();
        JSONObject o = new JSONObject();
        o.put("deleted", ok);
        return o;
    }

    /** Applies the "Wi-Fi only" switch to downloads that are already running. */
    private JSONObject net(JSONObject a) throws Exception {
        dl.setWifiOnly(dir(), a.optBoolean("wifiOnly", true));
        return new JSONObject();
    }
}
