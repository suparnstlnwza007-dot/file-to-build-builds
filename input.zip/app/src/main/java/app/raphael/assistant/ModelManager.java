package app.raphael.assistant;

import android.app.ActivityManager;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.StatFs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/**
 * Local file manager for downloadable AI files (language models in "models", voice models in "voices"). Downloads go through Android's DownloadManager, so they resume after
 * network drops, keep running in the background and show a system notification.
 * Files live in the app-private external dir (Android/data/app.raphael.assistant/files/<sub>),
 * which needs no storage permission and is removed when the app is uninstalled.
 */
class ModelManager {
    private final String sub;
    private final String[] exts;
    private final String label;
    private final Context ctx;
    private final DownloadManager dm;
    private final SharedPreferences sp;

    /** Language models (.gguf etc.) in files/models. */
    ModelManager(Context c) {
        this(c, "models", "raphael_models", "Raphael · ดาวน์โหลดโมเดล",
                new String[]{".gguf", ".task", ".bin", ".tflite", ".litertlm"});
    }

    /** Generic: sub-folder under the app's external files dir, prefs file name, notification label, allowed extensions. */
    ModelManager(Context c, String sub, String pref, String label, String[] exts) {
        this.sub = sub;
        this.exts = exts;
        this.label = label;
        ctx = c.getApplicationContext();
        dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
        sp = ctx.getSharedPreferences(pref, Context.MODE_PRIVATE);
    }

    JSONObject handle(String name, JSONObject a) throws Exception {
        String m = name.substring(name.indexOf('.') + 1); // "Models.list" / "Voices.list" -> "list"
        switch (m) {
            case "device": return device();
            case "list": return list();
            case "download": return download(a);
            case "cancel": return cancel(a.optString("file"));
            case "delete": return delete(a.optString("file"));
            default: throw new IllegalArgumentException("unknown method " + name);
        }
    }

    // ---------- helpers ----------
    private File dir() {
        File d = ctx.getExternalFilesDir(sub);
        if (d == null) d = new File(ctx.getFilesDir(), sub);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private boolean allowed(String lowerName) {
        for (String e : exts) if (lowerName.endsWith(e)) return true;
        return false;
    }

    /** Only plain file names with an allowed extension are accepted. */
    private String safeName(String f) {
        if (f == null) throw new IllegalArgumentException("missing file name");
        f = f.trim();
        if (f.length() == 0 || f.length() > 160 || f.contains("/") || f.contains("\\") || f.startsWith("."))
            throw new IllegalArgumentException("invalid file name");
        if (!allowed(f.toLowerCase(Locale.ROOT))) throw new IllegalArgumentException("unsupported file type");
        return f;
    }

    // ---------- device ----------
    private JSONObject device() throws Exception {
        JSONObject o = new JSONObject();
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        o.put("ramMB", mi.totalMem / (1024 * 1024));
        o.put("availRamMB", mi.availMem / (1024 * 1024));
        StatFs st = new StatFs(dir().getPath());
        o.put("freeMB", st.getAvailableBytes() / (1024 * 1024));
        o.put("totalMB", st.getTotalBytes() / (1024 * 1024));
        o.put("cores", Runtime.getRuntime().availableProcessors());
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
        o.put("abi64", Build.SUPPORTED_64_BIT_ABIS != null && Build.SUPPORTED_64_BIT_ABIS.length > 0);
        o.put("abi", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
        o.put("dir", dir().getAbsolutePath());
        return o;
    }

    // ---------- list (downloaded files + live download progress) ----------
    private JSONObject list() throws Exception {
        JSONArray files = new JSONArray();
        JSONArray active = new JSONArray();
        File d = dir();
        File[] fs = d.listFiles();
        java.util.HashSet<String> pending = new java.util.HashSet<String>();

        for (String key : sp.getAll().keySet()) {
            if (!key.startsWith("dl.")) continue;
            String file = key.substring(3);
            long id = sp.getLong(key, -1);
            JSONObject row = query(id);
            if (row == null) { sp.edit().remove(key).apply(); continue; }
            int status = row.optInt("status");
            row.put("file", file);
            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                sp.edit().remove(key).apply();
            } else if (status == DownloadManager.STATUS_FAILED) {
                dm.remove(id);
                sp.edit().remove(key).apply();
                new File(d, file).delete();
                active.put(row);
            } else {
                pending.add(file);
                active.put(row);
            }
        }
        if (fs != null) {
            for (File f : fs) {
                if (!f.isFile() || pending.contains(f.getName())) continue;
                if (!allowed(f.getName().toLowerCase(Locale.ROOT))) continue;
                JSONObject o = new JSONObject();
                o.put("file", f.getName());
                o.put("bytes", f.length());
                o.put("path", f.getAbsolutePath());
                files.put(o);
            }
        }
        JSONObject out = new JSONObject();
        out.put("files", files);
        out.put("active", active);
        return out;
    }

    private JSONObject query(long id) throws Exception {
        if (id < 0) return null;
        Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
        try {
            if (c == null || !c.moveToFirst()) return null;
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("status", c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS)));
            o.put("reason", c.getInt(c.getColumnIndex(DownloadManager.COLUMN_REASON)));
            o.put("bytes", c.getLong(c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
            o.put("total", c.getLong(c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
            return o;
        } finally {
            if (c != null) c.close();
        }
    }

    // ---------- download / cancel / delete ----------
    private JSONObject download(JSONObject a) throws Exception {
        String url = a.optString("url", "").trim();
        String file = safeName(a.optString("file"));
        if (!url.startsWith("https://")) throw new IllegalArgumentException("ต้องเป็นลิงก์ https เท่านั้น");

        if (sp.contains("dl." + file)) {
            JSONObject cur = query(sp.getLong("dl." + file, -1));
            if (cur != null && cur.optInt("status") != DownloadManager.STATUS_FAILED
                    && cur.optInt("status") != DownloadManager.STATUS_SUCCESSFUL) {
                JSONObject o = new JSONObject();
                o.put("id", cur.optLong("id"));
                o.put("already", true);
                return o;
            }
        }
        File target = new File(dir(), file);
        if (target.exists()) target.delete(); // DownloadManager would otherwise save as "name-1.gguf"

        long need = a.optLong("sizeMB", 0) * 1024L * 1024L;
        if (need > 0) {
            StatFs st = new StatFs(dir().getPath());
            if (st.getAvailableBytes() < need + 300L * 1024 * 1024)
                throw new IllegalStateException("พื้นที่ว่างไม่พอ (ต้องการ ~" + (need / (1024 * 1024)) + " MB + เผื่อ 300 MB)");
        }

        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
        r.setTitle(a.optString("title", file));
        r.setDescription(label);
        r.setDestinationInExternalFilesDir(ctx, sub, file);
        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        r.setAllowedOverRoaming(false);
        if (a.optBoolean("wifiOnly", true)) {
            r.setAllowedOverMetered(false);
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
        }
        String tok = a.optString("token", "").trim();
        if (tok.length() > 0) r.addRequestHeader("Authorization", "Bearer " + tok);
        r.addRequestHeader("User-Agent", "RaphaelApp/1.0");

        long id = dm.enqueue(r);
        sp.edit().putLong("dl." + file, id).apply();
        JSONObject o = new JSONObject();
        o.put("id", id);
        return o;
    }

    private JSONObject cancel(String f) throws Exception {
        String file = safeName(f);
        long id = sp.getLong("dl." + file, -1);
        if (id >= 0) dm.remove(id);
        sp.edit().remove("dl." + file).apply();
        new File(dir(), file).delete();
        return new JSONObject();
    }

    private JSONObject delete(String f) throws Exception {
        String file = safeName(f);
        long id = sp.getLong("dl." + file, -1);
        if (id >= 0) dm.remove(id);
        sp.edit().remove("dl." + file).apply();
        boolean ok = new File(dir(), file).delete();
        JSONObject o = new JSONObject();
        o.put("deleted", ok);
        return o;
    }
}
