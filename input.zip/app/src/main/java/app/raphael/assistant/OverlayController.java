package app.raphael.assistant;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Floating Raphael core (drawn by the web app's mini canvas) + speech bubble, shown over other apps. */
class OverlayController {
    private static final String TAG = "RaphaelOverlay";
    private final Context ctx;
    private final WindowManager wm;
    private final Handler main = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private ImageView icon;
    private TextView bubble;
    private WindowManager.LayoutParams lp;
    private volatile boolean visible = true;
    private final Runnable hideBubble = new Runnable() {
        @Override public void run() { if (bubble != null) bubble.setVisibility(View.GONE); }
    };

    OverlayController(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    static boolean canDraw(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    void create() { main.post(new Runnable() { @Override public void run() { doCreate(); } }); }

    private void doCreate() {
        if (root != null || !canDraw(ctx)) return;
        try {
            final float d = ctx.getResources().getDisplayMetrics().density;
            root = new LinearLayout(ctx);
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setGravity(Gravity.CENTER_VERTICAL);

            bubble = new TextView(ctx);
            bubble.setTextColor(0xFFE2F6FF);
            bubble.setTextSize(12);
            bubble.setLineSpacing(0, 1.15f);
            int p = (int) (9 * d);
            bubble.setPadding(p, p - 2, p, p - 2);
            bubble.setMaxWidth((int) (240 * d));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6020A22);
            bg.setStroke(Math.max(1, (int) d), 0x887FD4FF);
            bg.setCornerRadius(6 * d);
            bubble.setBackground(bg);
            bubble.setVisibility(View.GONE);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            blp.rightMargin = (int) (4 * d);

            icon = new ImageView(ctx);
            icon.setLayoutParams(new LinearLayout.LayoutParams((int) (96 * d), (int) (96 * d)));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);

            root.addView(bubble, blp);
            root.addView(icon);

            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = (int) (4 * d);
            lp.y = (int) (140 * d);

            icon.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy; int ox, oy; boolean moved;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                            if (Math.abs(dx) > 10 * d || Math.abs(dy) > 10 * d) moved = true;
                            if (moved) {
                                lp.x = ox - (int) dx;           // gravity END: x grows leftwards
                                lp.y = Math.max(0, oy + (int) dy);
                                try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) openApp();
                            return true;
                    }
                    return false;
                }
            });

            root.setVisibility(visible ? View.VISIBLE : View.GONE);
            wm.addView(root, lp);
        } catch (Throwable t) {
            Log.e(TAG, "overlay create failed", t);
            root = null;
        }
    }

    private void openApp() {
        try {
            Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (i == null) return;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            ctx.startActivity(i);
        } catch (Throwable t) { Log.e(TAG, "openApp failed", t); }
    }

    /** PNG with alpha from the web canvas. Safe to call from any thread. */
    void setFrame(byte[] png) {
        final Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (bmp == null) return;
        main.post(new Runnable() { @Override public void run() { if (icon != null) icon.setImageBitmap(bmp); } });
    }

    void setText(final String t) {
        main.post(new Runnable() { @Override public void run() {
            if (bubble == null) return;
            main.removeCallbacks(hideBubble);
            if (t == null || t.trim().length() == 0) { bubble.setVisibility(View.GONE); return; }
            bubble.setText(t);
            bubble.setVisibility(View.VISIBLE);
            main.postDelayed(hideBubble, 12000);
        } });
    }

    void setVisible(final boolean v) {
        visible = v;
        main.post(new Runnable() { @Override public void run() { if (root != null) root.setVisibility(v ? View.VISIBLE : View.GONE); } });
    }

    void remove() {
        main.post(new Runnable() { @Override public void run() {
            main.removeCallbacks(hideBubble);
            if (root != null) {
                try { wm.removeView(root); } catch (Throwable ignored) {}
                root = null; icon = null; bubble = null;
            }
        } });
    }
}
