package app.raphael.assistant;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Floating Raphael core (drawn by the web app's mini canvas) + speech bubble, shown over other apps.
 * v14.5: tapping the core opens a small menu (pause/resume, stop reading, back to the app, how often the AI reads)
 * so the screen-reading session can be controlled without opening Raphael. Labels and the current settings are
 * pushed by the web app (setMenu) so they follow the app language; taps are sent back through {@link #menuHandler}.
 */
class OverlayController {
    /** Receives taps on the floating menu: "stop", "pause" (toggle) and "iv" (value = seconds between reads). */
    interface MenuHandler { void onAction(String action, int value); }
    static volatile MenuHandler menuHandler;

    private static final String TAG = "RaphaelOverlay";
    private static final long MENU_IDLE_MS = 10000;
    private static final int MENU_W_DP = 232, CORE_DP = 96;

    private final Context ctx;
    private final WindowManager wm;
    private final Handler main = new Handler(Looper.getMainLooper());
    private float d = 1f;
    private LinearLayout root;      // window content: [core row] + [menu] (menu above or below, depending on room)
    private LinearLayout row;       // speech bubble + core
    private ImageView icon;
    private TextView bubble;
    private LinearLayout menu;      // null while the menu is closed
    private int menuShift;          // how far the window was moved up to fit the menu above the core
    private WindowManager.LayoutParams lp;
    private volatile boolean visible = true;
    private final Runnable hideBubble = new Runnable() {
        @Override public void run() { if (bubble != null) bubble.setVisibility(View.GONE); }
    };
    private final Runnable hideMenuRun = new Runnable() {
        @Override public void run() { hideMenu(); }
    };

    // menu content (defaults are Thai; the web app replaces them with the current language)
    private String tTitle = "กำลังอ่านหน้าจอ", tPaused = "พักอยู่", tPause = "พักชั่วคราว", tResume = "อ่านต่อ",
            tStop = "หยุดอ่านหน้าจอ", tOpen = "กลับเข้าแอป", tEvery = "AI อ่านทุก", tStopped = "หยุดอ่านหน้าจอแล้ว",
            unit = " วิ";
    private int[] ivs = {8, 15, 30, 60};
    private int iv = 15;
    private boolean paused = false;

    OverlayController(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    static boolean canDraw(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    void create() { main.post(new Runnable() { @Override public void run() { doCreate(); } }); }

    private void doCreate() {
        if (root != null || !canDraw(ctx)) return;
        try {
            d = ctx.getResources().getDisplayMetrics().density;
            final float dd = d;
            root = new LinearLayout(ctx);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.END);

            row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            bubble = new TextView(ctx);
            bubble.setTextColor(0xFFE2F6FF);
            bubble.setTextSize(12);
            bubble.setLineSpacing(0, 1.15f);
            int p = (int) (9 * dd);
            bubble.setPadding(p, p - 2, p, p - 2);
            bubble.setMaxWidth((int) (240 * dd));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6020A22);
            bg.setStroke(Math.max(1, (int) dd), 0x887FD4FF);
            bg.setCornerRadius(6 * dd);
            bubble.setBackground(bg);
            bubble.setVisibility(View.GONE);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            blp.rightMargin = (int) (4 * dd);

            icon = new ImageView(ctx);
            icon.setLayoutParams(new LinearLayout.LayoutParams((int) (CORE_DP * dd), (int) (CORE_DP * dd)));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);

            row.addView(bubble, blp);
            row.addView(icon);
            root.addView(row, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = (int) (4 * dd);
            lp.y = (int) (140 * dd);

            // a touch anywhere outside our window closes the menu (the touch itself still reaches the app below)
            root.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent e) {
                    if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) hideMenu();
                    return false;
                }
            });

            icon.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy; int ox, oy; boolean moved;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                            if (Math.abs(dx) > 10 * dd || Math.abs(dy) > 10 * dd) moved = true;
                            if (moved) {
                                lp.x = ox - (int) dx;           // gravity END: x grows leftwards
                                lp.y = Math.max(0, oy + (int) dy);
                                try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) toggleMenu();
                            return true;
                    }
                    return false;
                }
            });

            root.setVisibility(visible ? View.VISIBLE : View.GONE);
            wm.addView(root, lp);
        } catch (Throwable t) {
            Log.e(TAG, "overlay create failed", t);
            root = null;
        }
    }

    // ---------- menu ----------
    private void toggleMenu() {
        if (menu != null) hideMenu(); else showMenu();
    }

    private LinearLayout.LayoutParams menuLp() {
        LinearLayout.LayoutParams m = new LinearLayout.LayoutParams((int) (MENU_W_DP * d), LinearLayout.LayoutParams.WRAP_CONTENT);
        m.topMargin = (int) (2 * d);
        m.bottomMargin = (int) (2 * d);
        m.rightMargin = (int) (6 * d);
        return m;
    }

    private int screenHeight() {
        try {
            DisplayMetrics m = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            if (m.heightPixels > 0) return m.heightPixels;
        } catch (Throwable ignored) {}
        return ctx.getResources().getDisplayMetrics().heightPixels;
    }

    private void showMenu() {
        if (root == null || menu != null) return;
        try {
            menu = buildMenu();
            LinearLayout.LayoutParams mlp = menuLp();
            menu.measure(View.MeasureSpec.makeMeasureSpec(mlp.width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int mh = menu.getMeasuredHeight() + mlp.topMargin + mlp.bottomMargin;
            boolean above = lp.y + (int) (CORE_DP * d) + mh > screenHeight() - (int) (32 * d);
            root.removeAllViews();
            menuShift = 0;
            if (above) {
                int ny = Math.max(0, lp.y - mh);
                menuShift = lp.y - ny;
                lp.y = ny;
                root.addView(menu, mlp);
                root.addView(row);
            } else {
                root.addView(row);
                root.addView(menu, mlp);
            }
            wm.updateViewLayout(root, lp);
            armMenuHide();
        } catch (Throwable t) {
            Log.e(TAG, "menu show failed", t);
            menu = null;
        }
    }

    private void hideMenu() {
        main.removeCallbacks(hideMenuRun);
        if (menu == null || root == null) { menu = null; return; }
        try {
            root.removeView(menu);
            menu = null;
            if (menuShift != 0) { lp.y += menuShift; menuShift = 0; }
            wm.updateViewLayout(root, lp);
        } catch (Throwable t) {
            Log.e(TAG, "menu hide failed", t);
            menu = null;
        }
    }

    private void armMenuHide() {
        main.removeCallbacks(hideMenuRun);
        main.postDelayed(hideMenuRun, MENU_IDLE_MS);
    }

    /** Re-draws an open menu in place (state changed) without moving the window. */
    private void rebuildMenu() {
        if (menu == null || root == null) return;
        try {
            int idx = root.indexOfChild(menu);
            if (idx < 0) return;
            root.removeViewAt(idx);
            menu = buildMenu();
            root.addView(menu, idx, menuLp());
            armMenuHide();
        } catch (Throwable t) {
            Log.e(TAG, "menu rebuild failed", t);
        }
    }

    private TextView button(String text, int color, int fill) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight((int) (44 * d));
        t.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(Math.max(1, (int) d), 0x557FD4FF);
        g.setCornerRadius(8 * d);
        t.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = (int) (6 * d);
        t.setLayoutParams(p);
        return t;
    }

    private LinearLayout buildMenu() {
        LinearLayout m = new LinearLayout(ctx);
        m.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (10 * d);
        m.setPadding(pad, pad - 2, pad, pad + 2);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2020A22);
        bg.setStroke(Math.max(1, (int) d), 0xAA7FD4FF);
        bg.setCornerRadius(12 * d);
        m.setBackground(bg);

        TextView title = new TextView(ctx);
        title.setText(paused ? tTitle + " · " + tPaused : tTitle);
        title.setTextColor(0xFF7FD4FF);
        title.setTextSize(12);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        m.addView(title);

        TextView bp = button(paused ? tResume : tPause, 0xFFE2F6FF, 0x33103A66);
        bp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                paused = !paused;           // shown at once; the web app confirms with the next setMenu()
                fire("pause", 0);
                rebuildMenu();
            }
        });
        m.addView(bp);

        TextView bs = button(tStop, 0xFFFF9BAE, 0x33661030);
        bs.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopReading(); }
        });
        m.addView(bs);

        TextView bo = button(tOpen, 0xFFE2F6FF, 0x33103A66);
        bo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideMenu(); openApp(); }
        });
        m.addView(bo);

        TextView every = new TextView(ctx);
        every.setText(tEvery);
        every.setTextColor(0xFF9FB8D8);
        every.setTextSize(11);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        elp.topMargin = (int) (10 * d);
        m.addView(every, elp);

        LinearLayout chips = new LinearLayout(ctx);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (final int v : ivs) {
            boolean on = v == iv;
            TextView c = new TextView(ctx);
            c.setText(v + unit);
            c.setTextSize(12);
            c.setGravity(Gravity.CENTER);
            c.setTextColor(on ? 0xFFFFFFFF : 0xFFB8D8F0);
            c.setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
            c.setMinHeight((int) (40 * d));
            c.setPadding((int) (2 * d), (int) (4 * d), (int) (2 * d), (int) (4 * d));
            GradientDrawable g = new GradientDrawable();
            g.setColor(on ? 0x667FD4FF : 0x22103A66);
            g.setStroke(Math.max(1, (int) d), on ? 0xFF7FD4FF : 0x447FD4FF);
            g.setCornerRadius(8 * d);
            c.setBackground(g);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View x) {
                    iv = v;
                    fire("iv", v);
                    rebuildMenu();
                }
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            clp.topMargin = (int) (4 * d);
            clp.rightMargin = (int) (4 * d);
            chips.addView(c, clp);
        }
        m.addView(chips);
        return m;
    }

    private void fire(String action, int value) {
        MenuHandler h = menuHandler;
        if (h == null) return;
        try { h.onAction(action, value); } catch (Throwable t) { Log.w(TAG, "menu action failed: " + t); }
    }

    private void stopReading() {
        hideMenu();
        fire("stop", 0);                                  // web app: stops its loop and updates its switch
        try { Toast.makeText(ctx, tStopped, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
        ScreenCaptureService.requestStop(ctx);            // also directly, in case the web app is no longer there
    }

    /** Labels + current settings from the web app. Safe to call from any thread. */
    void setMenu(final JSONObject o) {
        if (o == null) return;
        main.post(new Runnable() { @Override public void run() {
            tTitle = o.optString("title", tTitle);
            tPaused = o.optString("paused", tPaused);
            tPause = o.optString("pause", tPause);
            tResume = o.optString("resume", tResume);
            tStop = o.optString("stop", tStop);
            tOpen = o.optString("open", tOpen);
            tEvery = o.optString("every", tEvery);
            tStopped = o.optString("stopped", tStopped);
            unit = o.optString("unit", unit);
            iv = o.optInt("iv", iv);
            paused = o.optBoolean("isPaused", paused);
            JSONArray a = o.optJSONArray("ivs");
            if (a != null && a.length() > 0 && a.length() <= 6) {
                int[] n = new int[a.length()];
                for (int i = 0; i < n.length; i++) n[i] = a.optInt(i, 15);
                ivs = n;
            }
            rebuildMenu();
        } });
    }

    private void openApp() {
        try {
            Intent i = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (i == null) return;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            ctx.startActivity(i);
        } catch (Throwable t) { Log.e(TAG, "openApp failed", t); }
    }

    /** PNG with alpha from the web canvas. Safe to call from any thread. */
    void setFrame(byte[] png) {
        final Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (bmp == null) return;
        main.post(new Runnable() { @Override public void run() { if (icon != null) icon.setImageBitmap(bmp); } });
    }

    void setText(final String t) {
        main.post(new Runnable() { @Override public void run() {
            if (bubble == null) return;
            main.removeCallbacks(hideBubble);
            if (t == null || t.trim().length() == 0) { bubble.setVisibility(View.GONE); return; }
            bubble.setText(t);
            bubble.setVisibility(View.VISIBLE);
            main.postDelayed(hideBubble, 12000);
        } });
    }

    void setVisible(final boolean v) {
        visible = v;
        main.post(new Runnable() { @Override public void run() {
            if (!v) hideMenu();
            if (root != null) root.setVisibility(v ? View.VISIBLE : View.GONE);
        } });
    }

    void remove() {
        main.post(new Runnable() { @Override public void run() {
            main.removeCallbacks(hideBubble);
            hideMenu();
            if (root != null) {
                try { wm.removeView(root); } catch (Throwable ignored) {}
                root = null; row = null; icon = null; bubble = null; menu = null;
            }
        } });
    }
}
