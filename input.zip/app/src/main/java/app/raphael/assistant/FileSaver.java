package app.raphael.assistant;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

/** Writes a text file to the public Downloads folder (a WebView cannot save blob: downloads). */
class FileSaver {
    static String safeName(String n) {
        if (n == null) n = "";
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.length() == 0) n = "raphael-" + System.currentTimeMillis() + ".json";
        if (n.length() > 100) n = n.substring(n.length() - 100);
        return n;
    }

    static boolean needsLegacyPermission() { return Build.VERSION.SDK_INT < 29; }

    /**
     * @param publicDir true -> Downloads (API 29+: no permission needed; API 24-28: needs WRITE_EXTERNAL_STORAGE)
     *                  false -> app-private folder Android/data/<pkg>/files/Download (fallback)
     */
    static JSONObject save(Context c, String name, String data, String mime, boolean publicDir) throws Exception {
        name = safeName(name);
        byte[] bytes = (data == null ? "" : data).getBytes(Charset.forName("UTF-8"));
        if (mime == null || mime.length() == 0) mime = "application/json";
        JSONObject o = new JSONObject();
        o.put("ok", true);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = c.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("สร้างไฟล์ใน Downloads ไม่ได้");
            try {
                OutputStream os = cr.openOutputStream(u);
                if (os == null) throw new Exception("เปิดไฟล์เขียนไม่ได้");
                try { os.write(bytes); os.flush(); } finally { os.close(); }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(u, done, null, null);
            } catch (Exception e) {
                try { cr.delete(u, null, null); } catch (Exception ignored) {}
                throw e;
            }
            o.put("where", "Downloads");
            o.put("name", name);
            return o;
        }
        File dir;
        String where;
        if (publicDir) {
            dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            where = "Downloads";
        } else {
            dir = c.getExternalFilesDir("Download");
            where = "Android/data/" + c.getPackageName() + "/files/Download";
        }
        if (dir == null) throw new Exception("ไม่พบโฟลเดอร์ปลายทาง");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("สร้างโฟลเดอร์ไม่ได้");
        File f = new File(dir, name);
        int k = 1;
        while (f.exists()) {   // never overwrite an existing backup
            int dot = name.lastIndexOf('.');
            String base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
            f = new File(dir, base + " (" + (k++) + ")" + ext);
        }
        FileOutputStream os = new FileOutputStream(f);
        try { os.write(bytes); os.flush(); } finally { os.close(); }
        o.put("where", where);
        o.put("name", f.getName());
        return o;
    }
}
