package app.raphael.assistant;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

/**
 * Registers Raphael as an accessibility service so the user can switch it on in system settings.
 * It currently reads and controls nothing (no window-content capability is declared in
 * res/xml/accessibility_service_config.xml); it only reports whether it is connected.
 */
public class RaphaelAccessibilityService extends AccessibilityService {
    static volatile boolean connected = false;

    @Override protected void onServiceConnected() { connected = true; }

    @Override public boolean onUnbind(Intent intent) { connected = false; return super.onUnbind(intent); }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* intentionally empty */ }

    @Override public void onInterrupt() { }
}
