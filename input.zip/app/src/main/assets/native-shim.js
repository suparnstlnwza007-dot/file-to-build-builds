/* Raphael native shim: exposes a Capacitor-compatible API on top of the Java bridge (RaphaelNative). */
(function () {
  if (window.Capacitor || typeof RaphaelNative === 'undefined') return;
  var P = {}, n = 0;
  window.__rphBg = false;
  window.__rphCb = function (id, ok, v) {
    var p = P[id]; if (!p) return; delete P[id];
    if (ok) p.res(v); else p.rej(new Error(String(v)));
  };
  function call(name, args) {
    return new Promise(function (res, rej) {
      var id = ++n; P[id] = { res: res, rej: rej };
      try { RaphaelNative.call(id, name, JSON.stringify(args || {})); }
      catch (e) { delete P[id]; rej(e); }
    });
  }
  function plugin(prefix, methods) {
    var o = {};
    methods.forEach(function (m) { o[m] = function (a) { return call(prefix + '.' + m, a); }; });
    return o;
  }
  var RS = plugin('RaphaelScreen', ['getInfo', 'overlayPermission', 'start', 'stop', 'isRunning', 'capture',
    'overlayFrame', 'overlayText', 'overlayVisible', 'goHome']);
  var RM = plugin('RaphaelModels', ['device', 'list', 'download', 'cancel', 'delete']);
  // plugin() prefixes calls with 'RaphaelModels.'; the Java side expects 'Models.'
  ['device', 'list', 'download', 'cancel', 'delete'].forEach(function (m) { RM[m] = function (a) { return call('Models.' + m, a); }; });
  var RV = {}, RA = {}, RF = {}, RSY = {};
  RF.saveDownload = function (a) { return call('Files.saveDownload', a); };
  ['setBars', 'getBars'].forEach(function (m) { RSY[m] = function (a) { return call('System.' + m, a); }; });
  ['device', 'list', 'download', 'cancel', 'delete'].forEach(function (m) { RV[m] = function (a) { return call('Voices.' + m, a); }; });
  ['status', 'open'].forEach(function (m) { RA[m] = function (a) { return call('Access.' + m, a); }; });
  var LN = plugin('LocalNotifications', ['requestPermissions', 'checkExactNotificationSetting',
    'changeExactNotificationSetting', 'cancel']);
  LN.schedule = function (opts) {
    var out = [];
    ((opts && opts.notifications) || []).forEach(function (x) {
      var s = x.schedule || {}, at = 0, daily = false;
      if (s.at) at = new Date(s.at).getTime();
      else if (s.on && s.on.hour != null) {
        var d = new Date(); d.setHours(s.on.hour, s.on.minute || 0, 0, 0);
        if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
        at = d.getTime(); daily = true;
      }
      if (at > 0) out.push({ id: x.id, title: x.title, body: x.body, at: at, daily: daily });
    });
    return call('LocalNotifications.schedule', { notifications: out });
  };
  /* ---- SpeechRecognition polyfill (WebView has none) on top of Android's SpeechRecognizer ---- */
  var cur = null;
  function NativeSR() {
    this.lang = 'th-TH'; this.interimResults = false; this.continuous = false;
    this.onstart = this.onresult = this.onerror = this.onend = null;
  }
  NativeSR.native = true;
  function fire(o, name, ev) { try { if (o && typeof o[name] === 'function') o[name](ev || {}); } catch (e) {} }
  function mkResult(text, isFinal) {
    var alt = { transcript: text, confidence: isFinal ? 0.9 : 0.5 };
    var r = [alt]; r.isFinal = isFinal; r.item = function (i) { return alt; };
    var rs = [r]; rs.item = function (i) { return r; };
    return { resultIndex: 0, results: rs };
  }
  NativeSR.prototype.start = function () {
    if (cur === this) throw new Error('already started');
    cur = this;
    call('Speech.start', { lang: this.lang, partial: !!this.interimResults }).catch(function () {
      if (cur === this) { var o = cur; cur = null; fire(o, 'onerror', { error: 'audio-capture' }); fire(o, 'onend'); }
    }.bind(this));
  };
  NativeSR.prototype.stop = function () { if (cur === this) call('Speech.stop').catch(function () {}); };
  NativeSR.prototype.abort = function () { if (cur === this) call('Speech.cancel').catch(function () {}); };
  NativeSR.prototype.addEventListener = function (n, f) { this['on' + n] = f; };
  NativeSR.prototype.removeEventListener = function (n) { this['on' + n] = null; };
  window.__rphSp = function (kind, p) {
    var o = cur; if (!o) return;
    if (kind === 'start') fire(o, 'onstart');
    else if (kind === 'partial') { if (o.interimResults && p && p.text) fire(o, 'onresult', mkResult(p.text, false)); }
    else if (kind === 'final') { if (p && p.text) fire(o, 'onresult', mkResult(p.text, true)); }
    else if (kind === 'error') fire(o, 'onerror', { error: (p && p.error) || 'unknown' });
    else if (kind === 'end') { cur = null; fire(o, 'onend'); }
  };
  if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
    window.SpeechRecognition = NativeSR; window.webkitSpeechRecognition = NativeSR;
  }

  window.Capacitor = {
    isNativePlatform: function () { return true; },
    getPlatform: function () { return 'android'; },
    isPluginAvailable: function (x) { return x === 'RaphaelScreen' || x === 'LocalNotifications' || x === 'RaphaelModels' || x === 'RaphaelVoices' || x === 'RaphaelAccess' || x === 'RaphaelFiles' || x === 'RaphaelSystem'; },
    registerPlugin: function (x) { return x === 'RaphaelScreen' ? RS : x === 'LocalNotifications' ? LN : x === 'RaphaelModels' ? RM : x === 'RaphaelVoices' ? RV : x === 'RaphaelAccess' ? RA : x === 'RaphaelFiles' ? RF : x === 'RaphaelSystem' ? RSY : {}; },
    Plugins: { RaphaelScreen: RS, LocalNotifications: LN, RaphaelModels: RM, RaphaelVoices: RV, RaphaelAccess: RA, RaphaelFiles: RF, RaphaelSystem: RSY }
  };
})();
