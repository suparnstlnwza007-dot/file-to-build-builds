# Raphael 14.5 (app.raphael.assistant) — สรุปการวิเคราะห์ APK

## 1. ภาพรวม
- แพ็กเกจ `app.raphael.assistant` · versionName 14.5 (code 145) · minSdk 24 · targetSdk 34 · AGP 8.5.2
- เป็นแอป **WebView wrapper** ไม่ใช่ native UI: โค้ด Java เล็ก (~110 KB dex) ส่วนตัวแอปจริงคือ `assets/index.html` (1.9 MB)
- แนวคิด: ผู้ช่วย AI ส่วนตัวธีม "ラファエル" (Raphael จาก Slime) UI 3 ภาษา th/en/ja, แกน 3D (raw WebGL), ความทรงจำ/อารมณ์/รายงานประจำวัน/เตือนความจำ
- ไม่มี native library (.so), ไม่มี Capacitor จริง — `native-shim.js` สร้าง `window.Capacitor` ปลอมครอบ `RaphaelNative` (Java bridge)
- APK ลงลายเซ็น (มี APK Signing Block) แต่ **debuggable="true"**

## 2. โครงสร้างไฟล์ใน APK
| ไฟล์ | หน้าที่ |
|---|---|
| `classes.dex` (2 KB) | เฉพาะ R classes |
| `classes2.dex` (110 KB) | โค้ดแอปทั้งหมด |
| `assets/index.html` | UI + logic ทั้งหมด (ดูข้อ 3) |
| `assets/native-shim.js` | Bridge JS → Java, polyfill SpeechRecognition |
| `res/xml/accessibility_service_config.xml` | event 0x20 (window state), `canRetrieveWindowContent=false` |

## 3. index.html แยกส่วน
1. CSS + inline bootstrap (โหลด localStorage/IndexedDB, backup/restore prompt)
2. `<script type="application/json" id="vpd">` — เสียง MP3 ญี่ปุ่น 19 คลิป base64 (~1.6 MB ≈ 83% ของไฟล์)
3. `<script type="text/plain" id="app">` — โค้ดหลัก 1,818 บรรทัด / 242K ตัวอักษร ถูก `eval` ผ่าน `createElement('script')` ตอน boot (มี fallback timeout 10 วิ)
4. dock toggle script ท้ายไฟล์

Section ใน app.js (เลขบรรทัดโดยประมาณ): i18n 64 · audio 558 · voice 606 · 3D core 668 · memory star map 740 · state machine 901 · scheduler 939 · APK bridge 989 · mic/wake word 1005 · memory engine 1040 · LLM orchestrator 1064 · external AI provider 1101 · panels 1234 · local model download 1290 · voice model download 1365 · permissions 1436 · backup 1460 · scenes 1551 · Initiative/Screen Watch 1595 · SFX 1690 · ENV 1714 · v31 cross-model 1733 · onboarding 1764

## 4. Native bridge (`RaphaelNative.call(id, "Plugin.method", json)`)
Screen: getInfo, overlayPermission, start, stop, isRunning, capture, overlayFrame/Text/Visible/Menu, goHome ·
Models / Voices: device, list, download, cancel, delete, net (รองรับ .gguf/.onnx/.tflite, HTTP Range resume) ·
Access: status, open · Files: saveDownload · System: setBars/getBars · Speech: start/stop/cancel/available · LocalNotifications: schedule/cancel (exact alarm)

Callback กลับมาที่ `window.__rphCb(id, ok, value)` และ `window.__rphSp(kind, payload)`

## 5. AI provider (เรียกจาก WebView ตรง ไม่ผ่าน backend)
Anthropic (default model `claude-sonnet-5-5`), Gemini, OpenAI, OpenRouter, Groq, Mistral, xAI, Ollama (ต้องใช้ IP เครื่อง ไม่ใช่ localhost) · ค้นเว็บผ่าน Tavily · อากาศ Open-Meteo
ตรวจชนิดคีย์อัตโนมัติจาก prefix · รองรับ provider ตัวที่สอง (`rph.api2`) สำหรับ cross-model review

localStorage keys: rph.api, rph.api2, rph.mem, rph.hist, rph.emo, rph.rem, rph.set, rph.watch, rph.files, rph.evo, rph.cdx, rph.mac, rph.day, rph.greet, rph.pos, rph.onb, rph.ini, rph.nodel, rph.errl, rph.bk, rph.vx, rph.vx.wifi, rph.lm.wifi

## 6. Permission ที่ขอ (กว้างมาก)
INTERNET, RECORD_AUDIO, CAMERA, ACCESS_FINE/COARSE_LOCATION, SYSTEM_ALERT_WINDOW, MANAGE_EXTERNAL_STORAGE, POST_NOTIFICATIONS, SCHEDULE_EXACT_ALARM, REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, FOREGROUND_SERVICE (+MEDIA_PROJECTION, +DATA_SYNC), WAKE_LOCK, VIBRATE
Component: MainActivity, CameraProvider, ScreenCaptureService (mediaProjection), DownloadService (dataSync), ReminderReceiver, RaphaelAccessibilityService, RaphaelNotificationListener

## 7. ข้อควรแก้ก่อนพัฒนาต่อ / ปล่อยจริง
| ระดับ | เรื่อง | แนวทาง |
|---|---|---|
| สูง | `debuggable="true"` | ปิดใน release build |
| สูง | API key เก็บ plaintext ใน localStorage + ส่ง header `anthropic-dangerous-direct-browser-access` | ย้ายไป Android Keystore/EncryptedSharedPreferences ผ่าน bridge หรือใช้ proxy ของตัวเอง |
| กลาง | `usesCleartextTraffic="true"` | จำกัดผ่าน networkSecurityConfig (อนุญาตเฉพาะ IP LAN สำหรับ Ollama) |
| กลาง | `addJavascriptInterface` + `setAllowFileAccess` | ตรวจว่า bridge ถูกเรียกเฉพาะจาก origin `appassets.androidplatform.net` และตรวจ argument ทุก method |
| กลาง | `innerHTML` 40 จุด ใน app.js | ข้อความจาก LLM/เว็บอาจเป็น XSS ที่เข้าถึง bridge ได้ — escape/sanitize |
| กลาง | `MANAGE_EXTERNAL_STORAGE` | Google Play จำกัดมาก ถ้าไม่จำเป็นให้ใช้ SAF/MediaStore |
| ต่ำ | เสียง base64 ในไฟล์ HTML 1.6 MB | ย้ายเป็นไฟล์ใน `assets/voices/` (โหลดเร็วขึ้น แก้ง่าย) |
| ต่ำ | ไม่มี source Java | ต้อง decompile (jadx) หรือเขียนใหม่ — ดูข้อ 9 |

หมายเหตุ: Accessibility service ในคอนฟิกตั้ง `canRetrieveWindowContent=false` และฟัง event แค่ window state — เน้นสั่ง goHome/overlay ไม่ได้อ่านเนื้อหาหน้าจอ ส่วน Screen capture ใช้ MediaProjection ซึ่งระบบขอ consent ทุกครั้ง

## 8. Workspace นี้
```
src/app.js                โค้ดหลัก (แก้ตรงนี้)
src/index.template.html   HTML/CSS/bootstrap มี {{VPD_JSON}} และ {{APP_JS}}
voices/*.mp3              เสียงที่แยกออกมา (+ _order.json)
native/native-shim.js     JS bridge
decoded/                  Manifest และ accessibility config ที่ถอดแล้ว
tools/axml.py             ตัวถอด binary XML
build.py                  ประกอบ dist/index.html (ตรวจแล้ว: ผลลัพธ์ byte-identical กับต้นฉบับ)
```
ทดสอบเร็ว: `python3 build.py && python3 -m http.server -d dist` (ฟีเจอร์ native จะ fallback เป็น Web API)

## 9. ขั้นตอนต่อไปที่แนะนำ
1. ถอด Java: `jadx -d java_src Raphael_14_5-1_0_0.apk` (หรือ apktool) เพื่อได้ NativeBridge / OverlayController / FileDownloader
2. สร้าง Android Studio project ใหม่ (minSdk 24, target 34), ใส่ Java ที่ถอดมา, copy `dist/index.html` + `native-shim.js` ไป `app/src/main/assets/`
3. แก้ข้อ "สูง" ในข้อ 7 ก่อน
4. แตก `app.js` เป็นโมดูล (memory / provider / scenes / native) เมื่อพร้อม

---
## 10. Changelog: v32 — เปลี่ยน CSS effect เป็น VFX จริง (WebGL shader)
**ไฟล์ใหม่:** `src/vfx.js` (build.py ต่อท้าย app.js ให้อัตโนมัติ) · ผลลัพธ์พร้อมใช้: `dist/index.html`

| ของเดิม (CSS) | แทนด้วย (shader ใน canvas `#vfx` เดียว) |
|---|---|
| `html::after` ดาว radial-gradient | starfield 3 ชั้น parallax + กะพริบ + halo |
| `#hex` mask ลายหกเหลี่ยม | hex grid คำนวณจริง ไหลช้า สว่างใกล้แกนกลาง |
| `#rays` conic-gradient | god-rays เป็นลำแสงเชิงมุม หมุน ความกว้างไม่สม่ำเสมอ จางตามระยะ |
| `.scan` แถบไล่สี | scan sweep แบบ gaussian (เร็วขึ้นตอน `analyze` เหมือนเดิม) |
| — | shockwave วงแหวน เมื่อเข้า analyze / result / danger, `window.VFX.pulse()` เรียกเองได้ |

**ผูกกับระบบเดิม (อ่านอย่างเดียว ไม่แก้ logic):** `html[data-st]` → ความแรงของรังสี, `--h` → สีเอฟเฟกต์ (ไล่สีนุ่ม), `#scan.f` → ความเร็ว scan, `html.pz` / `body.rfx` / `prefers-reduced-motion` → หยุดหรือซ่อน, `document.hidden` → ไม่เรนเดอร์
**Performance:** 1 draw call, เรนเดอร์ 75% ของความละเอียด, จำกัด ~30 fps, `powerPreference: low-power`
**Fallback:** ถ้า WebGL/shader ใช้ไม่ได้ จะไม่ใส่ class `html.vfx` และเลเยอร์ CSS เดิมทำงานต่อ

**ยังไม่ได้ทดสอบบน GPU จริง** (เครื่องวิเคราะห์ไม่มี browser/GPU): ตรวจแค่ JS syntax กับแก้จุดเสี่ยง GLSL ที่รู้ (smoothstep กลับด้าน, precision, pow ค่าลบ) — ให้ลองบนมือถือแล้วดู logcat/console หากขึ้น `VFX init failed`
**จูนค่า:** ใน `FS` ของ vfx.js — ความสว่างรังสี `Ray*(.22…)`, ความถี่ลำแสง `a*18.` / `a*7.`, ความหนาแน่นดาว `stars(...,14./26./48.)`, ความเร็ว sweep `fast?1.5:7`
