#!/usr/bin/env python3
"""Rebuild assets/index.html from src/ + voices/.  Usage: python3 build.py"""
import base64, glob, json, os
here = os.path.dirname(os.path.abspath(__file__))
tpl = open(f'{here}/src/index.template.html', encoding='utf8').read()
app = open(f'{here}/src/app.js', encoding='utf8').read()
if os.path.exists(f'{here}/src/vfx.js'):  # v32 real-VFX layer, appended after app.js
    app += '\n' + open(f'{here}/src/vfx.js', encoding='utf8').read()
vpd = {}
for p in sorted(glob.glob(f'{here}/voices/*.mp3')):
    vpd[os.path.basename(p)[:-4]] = 'data:audio/mpeg;base64,' + base64.b64encode(open(p, 'rb').read()).decode()
order = [k for k in json.load(open(f'{here}/voices/_order.json')) if k in vpd] + [k for k in vpd if k not in json.load(open(f'{here}/voices/_order.json'))]
vjson = '\n{\n' + ',\n'.join(f'"{k}":"{vpd[k]}"' for k in order) + '\n}\n'
out = tpl.replace('{{VPD_JSON}}', vjson).replace('{{APP_JS}}', app)
os.makedirs(f'{here}/dist', exist_ok=True)
open(f'{here}/dist/index.html', 'w', encoding='utf8').write(out)
print('built dist/index.html', len(out), 'chars')
