/* ===== VFX (v32): real fragment-shader effects layer =====
   Replaces the CSS stand-ins (html::after stars, #hex, #rays, .scan) with ONE WebGL pass:
   parallax starfield + hex grid + volumetric god-rays + scan sweep + state shockwave.
   Falls back to the old CSS layers automatically if WebGL is unavailable (html.vfx never set).
   Hooks (read-only): <html data-st>, style --h (hue), #scan.f, html.pz, body.rfx. API: window.VFX.pulse(). */
(function () {
  const H = document.documentElement, B = document.body;
  const cv = document.createElement('canvas'); cv.id = 'vfx'; cv.setAttribute('aria-hidden', 'true');
  cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none';
  let g, pr, U = {}, ok = false;
  const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
  const FS = `#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 R;uniform float T,Ray,Scan,Wave,Fl;uniform vec3 C;
float h1(vec2 q){return fract(sin(dot(q,vec2(127.1,311.7)))*43758.5453);}
vec2 h2(vec2 q){return vec2(h1(q),h1(q+19.7));}
float stars(vec2 uv,float cells,float spd,float sz){
  vec2 q=uv*cells+vec2(T*spd,T*spd*.35),id=floor(q),f=fract(q);
  vec2 o=h2(id)*.7+.15;float d=length(f-o),b=h1(id+7.3);
  float tw=.55+.45*sin(T*(1.5+b*3.)+b*40.);
  float core=1.-smoothstep(0.,sz,d),halo=(1.-smoothstep(0.,sz*5.,d))*.18;
  return (core+halo)*step(.55,b)*tw*(.4+b);}
float hexd(vec2 p){p=abs(p);return max(dot(p,vec2(.5,.866025)),p.x);}
float hexgrid(vec2 p){
  vec2 r=vec2(1.,1.7320508),h=r*.5,a=mod(p,r)-h,b=mod(p-h,r)-h;
  vec2 gv=dot(a,a)<dot(b,b)?a:b;return 1.-smoothstep(0.,.04,.5-hexd(gv));}
void main(){
  vec2 px=gl_FragCoord.xy,uv=px/R,asp=vec2(R.x/R.y,1.);
  vec2 ctr=vec2(.5,.54),p=(uv-ctr)*asp;float r=length(p);
  vec3 col=vec3(0.);
  /* stars: 3 parallax layers, white with a hue tint */
  float s=stars(uv*asp,14.,.004,.045)+stars(uv*asp+3.1,26.,.007,.04)*.8+stars(uv*asp+7.7,48.,.011,.035)*.6;
  col+=mix(vec3(1.),C,.35)*s;
  /* hex grid: faint, drifting, brighter near the core, pulsed by the shockwave */
  float hg=hexgrid(p*5.+vec2(T*.02,T*.012));
  float fall=1.-smoothstep(.1,1.2,r);
  col+=C*hg*(.05+.07*fall+Ray*.05);
  /* god-rays: angular shafts that slowly rotate, noisy width, radial falloff */
  float a=atan(p.y,p.x);
  float sh=sin(a*18.+T*.08)*.5+.5;sh=pow(max(sh,0.),6.)+pow(max(sin(a*7.-T*.05+sin(a*3.+T*.1)*2.)*.5+.5,0.),10.)*.7;
  float rm=smoothstep(.04,.14,r)*(1.-smoothstep(.1,1.3,r));
  col+=C*sh*rm*Ray*(.22+.06*sin(T*2.))*Fl;
  /* core glow */
  col+=C*exp(-r*r*14.)*(.05+Ray*.14);
  /* scan sweep (Scan = y position 0..1, <0 = off) */
  float sc=exp(-pow((uv.y-Scan)*7.,2.))*step(0.,Scan);
  col+=C*sc*.2*(.6+.4*sin(px.x*.35));
  /* shockwave ring (Wave = 0..1 progress, <0 = off) */
  if(Wave>=0.){float rr=Wave*1.1,ring=exp(-pow((r-rr)*18.,2.))*(1.-Wave);col+=mix(C,vec3(1.),.4)*ring*.6;}
  /* soft vignette so the layer never washes the UI */
  col*=(1.-smoothstep(.2,1.6,r))*.85+.15;
  float al=max(col.r,max(col.g,col.b));
  gl_FragColor=vec4(col,min(al,1.));
}`;
  function sh(t, s) { const o = g.createShader(t); g.shaderSource(o, s); g.compileShader(o); if (!g.getShaderParameter(o, g.COMPILE_STATUS)) throw new Error(g.getShaderInfoLog(o)); return o; }
  function init() {
    try {
      g = cv.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, powerPreference: 'low-power' });
      if (!g) return false;
      pr = g.createProgram(); g.attachShader(pr, sh(g.VERTEX_SHADER, VS)); g.attachShader(pr, sh(g.FRAGMENT_SHADER, FS)); g.linkProgram(pr);
      if (!g.getProgramParameter(pr, g.LINK_STATUS)) throw new Error('link');
      g.useProgram(pr);
      const b = g.createBuffer(); g.bindBuffer(g.ARRAY_BUFFER, b);
      g.bufferData(g.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), g.STATIC_DRAW);
      const l = g.getAttribLocation(pr, 'p'); g.enableVertexAttribArray(l); g.vertexAttribPointer(l, 2, g.FLOAT, false, 0, 0);
      ['R', 'T', 'Ray', 'Scan', 'Wave', 'Fl', 'C'].forEach(n => U[n] = g.getUniformLocation(pr, n));
      g.enable(g.BLEND); g.blendFunc(g.ONE, g.ONE_MINUS_SRC_ALPHA);
      return true;
    } catch (e) { try { console.warn('VFX init failed, CSS fallback', e); } catch (_) { } return false; }
  }
  function hsl(h) { h = ((h % 360) + 360) % 360 / 360; const s = 1, l = .72, q = l + s - l * s, p = 2 * l - q, f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < .5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; }; return [f(h + 1 / 3), f(h), f(h - 1 / 3)]; }
  function size() {
    const sc = .75, w = Math.max(2, Math.round(innerWidth * sc)), h = Math.max(2, Math.round(innerHeight * sc));
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; g.viewport(0, 0, w, h); }
  }
  /* smoothed state */
  let ray = 0, hue = 205, last = 0, t0 = performance.now(), wave0 = -1, prevSt = '', scanT = 0;
  const RAY = { listen: .55, analyze: 1, danger: 1 }, WAVE = { analyze: 1, result: 1, danger: 1 };
  function paused() { return document.hidden || H.classList.contains('pz') || B.classList.contains('rfx'); }
  function frame(now) {
    requestAnimationFrame(frame);
    if (!ok || now - last < 33) return;
    const dt = Math.min(.1, (now - last) / 1000); last = now;
    const rm = matchMedia('(prefers-reduced-motion:reduce)').matches;
    cv.style.display = (B.classList.contains('rfx')) ? 'none' : '';
    if (paused()) return;
    const st = H.dataset.st || 'idle';
    if (st !== prevSt) { if (WAVE[st] && prevSt) wave0 = now; prevSt = st; }
    ray += ((rm ? 0 : (RAY[st] || 0)) - ray) * Math.min(1, dt * 2.2);
    const hv = parseFloat(H.style.getPropertyValue('--h')); if (!isNaN(hv)) { let d = ((hv - hue + 540) % 360) - 180; hue = (hue + d * Math.min(1, dt * 6) + 360) % 360; }
    const se = document.getElementById('scan'), fast = !!(se && se.classList.contains('f'));
    scanT += dt / (fast ? 1.5 : 7); if (scanT > 1) scanT -= 1;
    const wv = wave0 < 0 ? -1 : (now - wave0) / 1100; if (wv >= 1) wave0 = -1;
    const c = hsl(hue);
    size();
    g.uniform2f(U.R, cv.width, cv.height); g.uniform1f(U.T, (now - t0) / 1000);
    g.uniform1f(U.Ray, ray); g.uniform1f(U.Scan, (scanT * 1.3 - .2)); g.uniform1f(U.Wave, wave0 < 0 ? -1 : wv);
    g.uniform1f(U.Fl, st === 'danger' ? .75 + .25 * Math.sin(now / 70) : 1); g.uniform3f(U.C, c[0], c[1], c[2]);
    g.clearColor(0, 0, 0, 0); g.clear(g.COLOR_BUFFER_BIT); g.drawArrays(g.TRIANGLES, 0, 3);
  }
  function start() {
    if (!B) return;
    if (!init()) return;
    B.insertBefore(cv, B.firstChild);
    const st = document.createElement('style');
    st.textContent = 'html.vfx #hex,html.vfx #rays,html.vfx::after,html.vfx .scan{display:none!important}';
    document.head.appendChild(st); H.classList.add('vfx'); ok = true;
    cv.addEventListener('webglcontextlost', e => { e.preventDefault(); ok = false; H.classList.remove('vfx'); });
    cv.addEventListener('webglcontextrestored', () => { U = {}; if (init()) { ok = true; H.classList.add('vfx'); } });
    requestAnimationFrame(frame);
  }
  window.VFX = { pulse() { wave0 = performance.now(); } };
  if (B) start(); else document.addEventListener('DOMContentLoaded', start, { once: true });
})();
