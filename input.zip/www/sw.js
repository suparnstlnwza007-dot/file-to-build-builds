const V='mb-v19',A=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','nacl-fast.min.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(A)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=V).map(x=>caches.delete(x)))));self.clients.claim()});
// network-first: อัปเดตเวอร์ชันใหม่ได้ทันที ออฟไลน์ค่อยใช้แคช (WebSocket/RPC ข้ามไม่แตะ)
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!='GET'||u.origin!=location.origin)return;
e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(V).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request)))});
