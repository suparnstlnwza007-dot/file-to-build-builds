import struct, sys
def parse(data):
    # header
    t, hs, size = struct.unpack_from('<HHI', data, 0)
    off = 8
    strings = []
    out = []
    ns = {}
    depth = 0
    RES = {0x0101021b:'versionCode',0x0101021c:'versionName',0x01010270:'targetSdkVersion',0x0101020c:'minSdkVersion',0x01010003:'name',0x01010001:'label',0x01010002:'icon',0x01010010:'exported',0x0101000e:'enabled',0x01010024:'value',0x01010025:'resource',0x01010026:'permission',0x0101001b:'launchMode', 0x010102d3:'networkSecurityConfig',0x0101028c:'usesCleartextTraffic',0x010102b8:'allowBackup', 0x01010280:'allowBackup',0x010104ec:'usesCleartextTraffic',0x01010004:'description'}
    while off < len(data):
        ct, chs, csz = struct.unpack_from('<HHI', data, off)
        if ct == 0x0001:  # string pool
            sc, stc, flags, ss, ssz = struct.unpack_from('<IIIII', data, off+8)
            utf8 = flags & 0x100
            offs = struct.unpack_from('<%dI' % sc, data, off+28)
            base = off + ss
            for o in offs:
                p = base + o
                if utf8:
                    l = data[p]; p += 1
                    if l & 0x80: l = ((l & 0x7f) << 8) | data[p]; p += 1
                    l2 = data[p]; p += 1
                    if l2 & 0x80: l2 = ((l2 & 0x7f) << 8) | data[p]; p += 1
                    strings.append(data[p:p+l2].decode('utf8','replace'))
                else:
                    l = struct.unpack_from('<H', data, p)[0]; p += 2
                    if l & 0x8000:
                        l2 = struct.unpack_from('<H', data, p)[0]; p += 2; l = ((l & 0x7fff) << 16) | l2
                    strings.append(data[p:p+l*2].decode('utf-16le','replace'))
        elif ct == 0x0102:  # start element
            line, cmt, nsi, name, astart, asz, ac, idi, ci, si = struct.unpack_from('<IIiiHHHHHH', data, off+8)
            tag = strings[name]
            attrs = []
            ap = off + 16 + astart
            for i in range(ac):
                ans, an, raw, vsz, res0, vt, vd = struct.unpack_from('<iiiHBBI', data, ap + i*20)
                aname = strings[an] if an >= 0 else '?'
                if raw >= 0: val = strings[raw]
                elif vt == 3: val = strings[vd]
                elif vt == 0x12: val = 'true' if vd else 'false'
                elif vt == 0x10: val = str(vd)
                elif vt == 0x11: val = hex(vd)
                elif vt == 1: val = '@0x%x' % vd
                elif vt == 2: val = '?0x%x' % vd
                else: val = '(t%d)%d' % (vt, vd)
                attrs.append('%s="%s"' % (aname, val))
            out.append('  '*depth + '<' + tag + (' ' + ' '.join(attrs) if attrs else '') + '>')
            depth += 1
        elif ct == 0x0103:
            depth -= 1
        off += csz
    return '\n'.join(out)
print(parse(open(sys.argv[1],'rb').read()))
